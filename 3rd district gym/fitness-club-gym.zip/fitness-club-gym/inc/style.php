<?php    
/**
 * @package Luzuk Premium
 */
function total_dymanic_styles(){
    global $post;
  $primColor = get_theme_mod( 'luzuk_template_color', '#f7c605' );

  $headerrespnavtoggbarheadbgclr = get_theme_mod( 'header_respnavtoggbarheadbgclr', '#fff' );
  $headerrespmailphoneColor = get_theme_mod( 'header_respmailphoneColor', '#000' );

    $navigationrespnavtoggbarbgssColor = get_theme_mod( 'header_respnavtoggbarbgssColor', '#000' );
    $navigationrespnavbsbgssColor = get_theme_mod( 'header_respnavbsbgssColor', '#fff' );
    $navigationrespnavmenutitleColor = get_theme_mod( 'header_navigationrespnavbrssColor', '#000' );
    $navigationrespnavmenutitlebgColor = get_theme_mod( 'header_navigationrespnavmenuttlbgColor', '#d5d5d5' );
    $navigationrespnavmenuColor = get_theme_mod( 'header_navigationrespnavmenuColor', '#fff' );
    $navigationrespnavmenubgColor = get_theme_mod( 'header_navigationrespnavmenubgColor', '#000' );
 
    $color_rgba = totalColourBrightness($primColor, 0.3);
    // echo '<br>Dark color: '.
    $darker_color = totalColourBrightness($primColor, -0.5);

    $header_image = get_header_image();
    // DYNAMIC FONTS
    // echo '<br> heading font '.
    $headeingFontRow = get_theme_mod('luzuk_general_headeing_font', '31');
    $textFontRow = get_theme_mod('luzuk_general_text_font', '31');
    $headerinn = get_theme_mod('header_textcolor', '#666666'); //header color

// fot bottom header padding
$headerlogoTopsetmaxwidth = get_theme_mod('pages_logoTopsetmaxwidth', '100');

$headerlogoTpadding = get_theme_mod('pages_logoTpadding', '0px');
$headerlogoBpadding = get_theme_mod('pages_logoBpadding', '0px');
$headerlogoLpadding = get_theme_mod('pages_logoLpadding', '0px');
$headerlogoRpadding = get_theme_mod('pages_logoRpadding', '0px');

// section opacity
$sliderOpacity = get_theme_mod('slider_areaOpacity', '0.1');
$appOpacity = get_theme_mod('app_Opacity', '1');
$appOpacityrhs = get_theme_mod('app_Opacityrhs', '1');

$innheadrOpacity = get_theme_mod('innheadr_Opacity', '0.3');

  //Counter section
$abtsectiontoppadding = get_theme_mod('about_areaTpadding', '5em');
$abtsectionbottompadding = get_theme_mod('about_areaBpadding', '4em');

//Services section
$servicesTpadding = get_theme_mod('service_areaTpadding', '4em');
$servicesBpadding = get_theme_mod('service_areaBpadding', '3em');

 //contact section
$contactsectoppadding = get_theme_mod('contactsection_toppadding', '4em');
$contactsecbottompadding = get_theme_mod('contactsection_bottompadding', '4em');

//footer
$SectionfooterseTmargin = get_theme_mod('sec_footerseTmargin', '0em');
$Sectionfootersebottommargin = get_theme_mod('sec_footersebottommargin', '0em');

//inner page
  $headerinnerpageheading = get_theme_mod('pages_innerpageheading', '35px');
  $headerinnerpageheading2 = get_theme_mod('pages_innerpageheading2', '37px');
  $headerinnerpageheading3 = get_theme_mod('pages_innerpageheading3', '20px');
  $headerinnerpageheading4 = get_theme_mod('pages_innerpageheading4', '18px');
  $headerinnerpageheading5 = get_theme_mod('pages_innerpageheading5', '17px');
  $headerinnerpageheading6 = get_theme_mod('pages_innerpageheading6', '16px');

  $immerpageheadertitleboxTpadding = get_theme_mod('inner_headertitleboxTpadding', '5em');
  $immerpageheadertitleboxBpadding = get_theme_mod('inner_headertitleboxBpadding', '5em');

  $bloginnerpageheading2 = get_theme_mod('blogpages_innerpageheading2', '23px');
  $contactpagesheading4 = get_theme_mod('contactpages_innerpageheading2', '40px');
  $productpagesheading2 = get_theme_mod('productpages_productheading2', '20px');

  $headingFont = getFonts(false, (int)$headeingFontRow);
  $textFont = getFonts(false, (int)$textFontRow);

    $custom_css = '';
    $custom_css = "
body,
.btn,
.btn span,
.btn small, 
.btn strong,
.btn big, 
.btn b,
.btn sup,
.btn sub,
.navigation .mainmenu>li>a,
.footer-area .widget.widget_recent_entries li a, * {font-family: $textFont;}

h2.lz-about-heading,
h2.lz-facility-heading, 
.ht-section-title, 
.luzuk-h2, 
.ht-title-wrap, 
.ht-slide-cap-title, 
#ht-princing-post-section .ht-princing-icon,h1, h2, h3, h4, h5, h6,

.slider_section .title,
.slider_section .title small,
.slider_section .title strong, 
.slider_section .title b,
.slider_section .title big,
.slider_section .title sub,
.slider_section .title sup,

.section-title .subheading,
.section-title .subheading span,
.section-title .subheading small,
.section-title .subheading strong,
.section-title .subheading b,
.section-title .subheading big,
.section-title .subheading sub,
.section-title .subheading sup,

.subheading,
.subheading span,
.subheading small,
.subheading strong,
.subheading b,
.subheading big,
.subheading sub,
.subheading sup,

.section-title h2,  
.section-title h2 small, 
.section-title h2 strong, 
.section-title h2 big, 
.section-title h2 b, 
.section-title h2 sub, 
.section-title h2 sup,
.section-title h2 span,

.section-title h3,  
.section-title h3 small, 
.section-title h3 strong, 
.section-title h3 big, 
.section-title h3 b, 
.section-title h3 sub, 
.section-title h3 sup,
.section-title h3 span,

.inner-area-title, 
.inner-area-title small, 
.inner-area-title span, 
.inner-area-title strong, 
.inner-area-title sub, 
.inner-area-title sup, 
.inner-area-title big, 
.inner-area-title b,

.inner_contentbox h4, 
.inner_contentbox h4 small, 
.inner_contentbox h4 span, 
.inner_contentbox h4 strong, 
.inner_contentbox h4 sub, 
.inner_contentbox h4 sup, 
.inner_contentbox h4 big, 
.inner_contentbox h4 b,

#innerpage-box .faq-heading, 
#innerpage-box .faq-heading small, 
#innerpage-box .faq-heading span, 
#innerpage-box .faq-heading strong, 
#innerpage-box .faq-heading sub, 
#innerpage-box .faq-heading sup, 
#innerpage-box .faq-heading big, 
#innerpage-box .faq-heading b,

main#innerpage-box div#content-box h3.faq-title, 
main#innerpage-box div#content-box h3.faq-title small,
main#innerpage-box div#content-box h3.faq-title span, 
main#innerpage-box div#content-box h3.faq-title strong,
main#innerpage-box div#content-box h3.faq-title sub, 
main#innerpage-box div#content-box h3.faq-title sup,
main#innerpage-box div#content-box h3.faq-title big, 
main#innerpage-box div#content-box h3.faq-title b,

.inner-page-gallery .text,
.inner-page-gallery .text small,
.inner-page-gallery .text span, 
.inner-page-gallery .text strong,
.inner-page-gallery .text sub, 
.inner-page-gallery .text sup,
.inner-page-gallery .text big, 
.inner-page-gallery .text b,

#innerpage-box h6.ts-area-title, 
#innerpage-box h6.ts-area-title small,
#innerpage-box h6.ts-area-title span, 
#innerpage-box h6.ts-area-title strong,
#innerpage-box h6.ts-area-title sub, 
#innerpage-box h6.ts-area-title sup,
#innerpage-box h6.ts-area-title big, 
#innerpage-box h6.ts-area-title b,

#ht-contactus-wrap .contact_l_area,
#ht-contactus-wrap .contact_l_area small, 
#ht-contactus-wrap .contact_l_area span,
#ht-contactus-wrap .contact_l_area strong,
#ht-contactus-wrap .contact_l_area sub,
#ht-contactus-wrap .contact_l_area sup,
#ht-contactus-wrap .contact_l_area big,
#ht-contactus-wrap .contact_l_area b,

#ht-contactus-wrap h1,
#ht-contactus-wrap h1 small, 
#ht-contactus-wrap h1 strong,
#ht-contactus-wrap h1 span, 
#ht-contactus-wrap h1 sub,
#ht-contactus-wrap h1 sup,
#ht-contactus-wrap h1 big,
#ht-contactus-wrap h1 b,

main#innerpage-box .Address_area h4, 
main#innerpage-box .Address_area h4 small,
main#innerpage-box .Address_area h4 strong,
main#innerpage-box .Address_area h4 span,
main#innerpage-box .Address_area h4 sub,
main#innerpage-box .Address_area h4 sup,
main#innerpage-box .Address_area h4 big,
main#innerpage-box .Address_area h4 b,

main#innerpage-box .social_area h4, 
main#innerpage-box .social_area h4 small,
main#innerpage-box .social_area h4 strong,
main#innerpage-box .social_area h4 span,
main#innerpage-box .social_area h4 sub,
main#innerpage-box .social_area h4 sup,
main#innerpage-box .social_area h4 big, 
main#innerpage-box .social_area h4 b,

.woocommerce div.product .product_title,
.woocommerce div.product .product_title span,
.woocommerce div.product .product_title small, 
.woocommerce div.product .product_title strong,
.woocommerce div.product .product_title big, 
.woocommerce div.product .product_title b,
.woocommerce div.product .product_title sup,
.woocommerce div.product .product_title sub,

main#innerpage-box h2.woocommerce-loop-product__title,
main#innerpage-box h2.woocommerce-loop-product__title span,
main#innerpage-box h2.woocommerce-loop-product__title small, 
main#innerpage-box h2.woocommerce-loop-product__title strong,
main#innerpage-box h2.woocommerce-loop-product__title big, 
main#innerpage-box h2.woocommerce-loop-product__title b,
main#innerpage-box h2.woocommerce-loop-product__title sup,
main#innerpage-box h2.woocommerce-loop-product__title sub,

.service-area h4,
.service-area h4 sub,
.service-area h4 sup,
.service-area h4 span,
.service-area h4 small,
.service-area h4 strong,
.service-area h4 big,
.service-area h4 b,

body.page-template-default main#innerpage-box h4, div#commentsAdd h4, 
body.page-template-default main#innerpage-box h4 span, div#commentsAdd h4 span,
body.page-template-default main#innerpage-box h4 small, div#commentsAdd h4 small,
body.page-template-default main#innerpage-box h4 strong, div#commentsAdd h4 strong,
body.page-template-default main#innerpage-box h4 sub, div#commentsAdd h4 sub,
body.page-template-default main#innerpage-box h4 sup, div#commentsAdd h4 sup,
body.page-template-default main#innerpage-box h4 big, div#commentsAdd h4 big,
body.page-template-default main#innerpage-box h4 b, div#commentsAdd h4 b,

.page-template-default #innerpage-box .service_inbox .title a, 
.page-template-default #innerpage-box .service_inbox .title a small,
.page-template-default #innerpage-box .service_inbox .title a sub,
.page-template-default #innerpage-box .service_inbox .title a sup,
.page-template-default #innerpage-box .service_inbox .title a span,
.page-template-default #innerpage-box .service_inbox .title a strong,
.page-template-default #innerpage-box .service_inbox .title a big,
.page-template-default #innerpage-box .service_inbox .title a b,

.call-label,
.call-label small,
.call-label sub,
.call-label sup,
.call-label span,
.call-label strong,
.call-label big,
.call-label b,

.contact-content .phone,
.contact-content .phone small,
.contact-content .phone sub,
.contact-content .phone sup,
.contact-content .phone span,
.contact-content .phone strong,
.contact-content .phone big,
.contact-content .phone b,

.section-title h3,
.section-title h3 small,
.section-title h3 sub,
.section-title h3 sup,
.section-title h3 span,
.section-title h3 strong,
.section-title h3 big,

#about-section h4,
#about-section h4 small,
#about-section h4 sub,
#about-section h4 sup,
#about-section h4 span,
#about-section h4 strong,
#about-section h4 big,

.apphead h3,
.apphead h3 span,
.apphead h3 small,
.apphead h3 strong,
.apphead h3 b,
.apphead h3 big,
.apphead h3 sub,
.apphead h3 sup,

.ts-area-title,
.ts-area-title span,
.ts-area-title small,
.ts-area-title strong,
.ts-area-title b,
.ts-area-title big,
.ts-area-title sub,
.ts-area-title sup,

.text-designation,
.text-designation span,
.text-designation small,
.text-designation strong,
.text-designation b,
.text-designation big,
.text-designation sub,
.text-designation sup,

#footer.footer-area .widget-title {font-family: $headingFont; }

.top-bar-head{ background: url('$header_image'); background-repeat: no-repeat; background-size: cover;}

#ht-masthead, .ht-site-description a, 
.page-template-home-template .ht-main-navigation .menu-item > a, 
.ht-main-navigation a, 
.ht-main-navigation ul ul a {color: #{$headerinn};}

.page-template-home-template .ht-main-navigation .current_page_item > a {color: #fff;}

.logo-header.mostion img{max-width: $headerlogoTopsetmaxwidth%;}

.logo-header.mostion img{padding-top: $headerlogoTpadding;}
.logo-header.mostion img{padding-bottom: $headerlogoBpadding;}
.logo-header.mostion img{padding-left: $headerlogoLpadding;}
.logo-header.mostion img{padding-right: $headerlogoRpadding;}

.slider_gradiant{opacity: $sliderOpacity;}
.page-main-header .overlay1{opacity: $innheadrOpacity;}

#about{padding-top: $abtsectiontoppadding;}
#about{padding-bottom: $abtsectionbottompadding;}

#service{padding-top: $servicesTpadding;}
#service{padding-bottom: $servicesBpadding;}

.footer-area{padding-top: $SectionfooterseTmargin;}
.footer-area .top-area{padding-bottom: $Sectionfootersebottommargin;}

.page-main-header{padding-top: $immerpageheadertitleboxTpadding;}
.page-main-header{padding-bottom: $immerpageheadertitleboxBpadding;}

main#innerpage-box h1,
body.page-template-default main#innerpage-box h1, .ht-main-title,
#ht-contactus-wrap h1{font-size: $headerinnerpageheading;}

body.page-template-default main#innerpage-box h2,
main#innerpage-box h2,
h1.product_title.entry-title{font-size: $headerinnerpageheading2;}

main#innerpage-box h3,
body.page-template-default main#innerpage-box h3,
#innerpage-box div#content-box .teamdesbox h3,
.widget .widget-title, .widget .post-title,
div#sitemap-box h3{font-size: $headerinnerpageheading3;}

main#innerpage-box h4,
div#commentsAdd h4,
main#innerpage-box .main-inner-ser-bx h4.panel-header a{font-size: $headerinnerpageheading4;}

main#innerpage-box h5{font-size: $headerinnerpageheading5;}
main#innerpage-box h6,
body.page-template-default main#innerpage-box h6,
div#blog-box.innerpage-whitebox h6{font-size: $headerinnerpageheading6;}

main#innerpage-box #blog-box h2{font-size: $bloginnerpageheading2;}
main#innerpage-box .Address_area h4, main#innerpage-box .social_area h4,.page-template-contact-template main#innerpage-box .Address_area h4, .page-template-contact-template main#innerpage-box .social_area h4{font-size: $contactpagesheading4;}
    
main#innerpage-box h2.woocommerce-loop-product__title{font-size: $productpagesheading2;}

    ";

    $custom_css .= "
    button,
    input[type='button'],
    input[type='reset'],
    input[type='submit'],
    .widget-area .widget-title:after,
    h3#reply-title:after,
    h3.comments-title:after,
    .nav-previous a,
    .nav-next a,  
    .ht-progress-bar-length,
    .ht-service-post-wrap:after,
    .ht-service-icon,
    .ht-testimonial-wrap .bx-wrapper .bx-controls-direction a,
    .ht-cta-buttons a.ht-cta-button1,
    .ht-cta-buttons a.ht-cta-button2:hover,
    #ht-back-top:hover,
    .entry-readmore a,
    .woocommerce #respond input#submit, 
    .woocommerce a.button, 
    .woocommerce button.button, 
    .woocommerce input.button,
    .woocommerce ul.products li.product:hover .button,
    .woocommerce #respond input#submit.alt, 
    .woocommerce a.button.alt, 
    .woocommerce button.button.alt, 
    .woocommerce input.button.alt,
    .woocommerce nav.woocommerce-pagination ul li a, 
    .woocommerce nav.woocommerce-pagination ul li span,
    .woocommerce span.onsale,
    .woocommerce div.product .woocommerce-tabs ul.tabs li.active,
    .woocommerce #respond input#submit.disabled, 
    .woocommerce #respond input#submit:disabled, 
    .woocommerce #respond input#submit:disabled[disabled], 
    .woocommerce a.button.disabled, .woocommerce a.button:disabled, 
    .woocommerce a.button:disabled[disabled], 
    .woocommerce button.button.disabled, 
    .woocommerce button.button:disabled, 
    .woocommerce button.button:disabled[disabled], 
    .woocommerce input.button.disabled, 
    .woocommerce input.button:disabled, 
    .woocommerce input.button:disabled[disabled],
    .woocommerce #respond input#submit.alt.disabled, 
    .woocommerce #respond input#submit.alt.disabled:hover, 
    .woocommerce #respond input#submit.alt:disabled, 
    .woocommerce #respond input#submit.alt:disabled:hover, 
    .woocommerce #respond input#submit.alt:disabled[disabled], 
    .woocommerce #respond input#submit.alt:disabled[disabled]:hover, 
    .woocommerce a.button.alt.disabled, 
    .woocommerce a.button.alt.disabled:hover, 
    .woocommerce a.button.alt:disabled, 
    .woocommerce a.button.alt:disabled:hover, 
    .woocommerce a.button.alt:disabled[disabled], 
    .woocommerce a.button.alt:disabled[disabled]:hover, 
    .woocommerce button.button.alt.disabled, 
    .woocommerce button.button.alt.disabled:hover, 
    .woocommerce button.button.alt:disabled, 
    .woocommerce button.button.alt:disabled:hover, 
    .woocommerce button.button.alt:disabled[disabled], 
    .woocommerce button.button.alt:disabled[disabled]:hover, 
    .woocommerce input.button.alt.disabled, 
    .woocommerce input.button.alt.disabled:hover, 
    .woocommerce input.button.alt:disabled, 
    .woocommerce input.button.alt:disabled:hover, 
    .woocommerce input.button.alt:disabled[disabled], 
    .woocommerce input.button.alt:disabled[disabled]:hover,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
    .woocommerce-MyAccount-navigation-link a,
    #ht-princing-post-section .ht-princing-icon,
    .ht-princing-icon,      
    .readmore a,
    .page-main-header,
    #content-box ol li:before,
    .ht-slide-cap-descmore a,
    .days-time-day,
    .lz-facility-text ul li i,
    .facility-icon,
    .pagingation .current,
    .pagingation a:hover,
    .ht-appintment-member-wrap:after,
    #commentsAdd input[type='submit'],
    section#inner-blog-section .readMore:hover,
    .woocommerce ul.products li.product .button,
    .woocommerce #content div.product .woocommerce-tabs ul.tabs li:hover, .woocommerce div.product .woocommerce-tabs ul.tabs li:hover, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li:hover, .woocommerce-page div.product .woocommerce-tabs ul.tabs li:hover,
    .ht-main-navigation ul ul,
    .pagination .page-numbers.current, .pagination a.page-numbers:hover,
    div#sitemap-box h3,
    .ht-blog-thumbnail .socialMedia a,
    .widget-area .widget-title,
    .widget_calendar tfoot tr td a,
    .pagination .page-numbers
    {
        background:{$primColor};
    }
    .ht-post-info .entry-date span.ht-day,
    .entry-categories .fa,
    .widget-area a:hover,
    .comment-list a:hover,
    .no-comments,
    .woocommerce .woocommerce-breadcrumb a:hover,
    #total-breadcrumbs a:hover,
    .ht-featured-link a,
    .ht-portfolio-cat-name-list .fa,
    .ht-portfolio-cat-name:hover, 
    .ht-portfolio-cat-name.active,
    .ht-portfolio-caption a,
    .ht-team-detail,
    .ht-counter-icon,
    .woocommerce ul.products li.product .price,
    .woocommerce div.product p.price, 
    .woocommerce div.product span.price,
    .woocommerce .product_meta a:hover,
    .woocommerce-error:before, 
    .woocommerce-info:before, 
    .woocommerce-message:before,
    .featured-post:after,
    .featured-post:before,
    .featured-link a,
    .breadcrumbbox a,
    #ht-colophon .social-profile-icons a:hover,
    footer#ht-colophon ul li a:hover,
    .ht-footer .textwidget .fa,
    h6.secondry-text,
    #ht-about-us-section ul li:before,
    .pluses.text-right i.fa.fa-plus,
    .ht-section-tagline.lz-newslatter-text b,
    #content-box ul li:before,
    .offtimebox h4.offtime-text,
    #ht-masthead .header-social-links span:hover,
    #ht-masthead ul.header-menu-links li.mailto a:hover,
    .ht-slider-highlighttext,
    .edit-link a,
    .inner-blog-post .socialMedia a:hover,
    #comments a, 
    #commentsAdd a,
    #content-box a,
    #content-box a i:hover,
    #respond .stars span a,
    #content-box .socialMedia a:hover,
    .post-date-publishable i,
    .woocommerce .star-rating span,
    .woocommerce div.product .woocommerce-product-rating a,
    #content-box .socialbxsinglepost:hover a i,
    section#inner-blog-section h2.title small,
    section#inner-blog-section h2.title a,
    div#secondary li.current_page_item > a,
    div#secondary .social-profile-icons ul li i,
    .woocommerce .star-rating::before,
    .socialMedia a:hover,
    .luzuk-time div:nth-child(8) div.days-time-day,
    div#content-box header.woocommerce-Address-title.title a:hover,
    #blog-box .ht-blog-date, #blog-box .ht-blog-date .fa,
    .widget-area ul li:before,
    .woocommerce table.shop_attributes th,
    .widget-area span.woocommerce-Price-amount.amount {color:{$primColor};}

    .ht-featured-link a,
    .ht-counter,
    .ht-testimonial-wrap .bx-wrapper img,
    .ht-blog-post,
    #ht-colophon,
    .woocommerce ul.products li.product:hover, 
    .woocommerce-page ul.products li.product:hover,
    .woocommerce #respond input#submit, 
    .woocommerce a.button, 
    .woocommerce button.button, 
    .woocommerce input.button,
    .woocommerce ul.products li.product:hover .button,
    .woocommerce #respond input#submit.alt, 
    .woocommerce a.button.alt, 
    .woocommerce button.button.alt, 
    .woocommerce input.button.alt,
    .woocommerce div.product .woocommerce-tabs ul.tabs,
    .woocommerce #respond input#submit.alt.disabled, 
    .woocommerce #respond input#submit.alt.disabled:hover, 
    .woocommerce #respond input#submit.alt:disabled, 
    .woocommerce #respond input#submit.alt:disabled:hover, 
    .woocommerce #respond input#submit.alt:disabled[disabled], 
    .woocommerce #respond input#submit.alt:disabled[disabled]:hover, 
    .woocommerce a.button.alt.disabled, 
    .woocommerce a.button.alt.disabled:hover, 
    .woocommerce a.button.alt:disabled, 
    .woocommerce a.button.alt:disabled:hover, 
    .woocommerce a.button.alt:disabled[disabled], 
    .woocommerce a.button.alt:disabled[disabled]:hover, 
    .woocommerce button.button.alt.disabled, 
    .woocommerce button.button.alt.disabled:hover, 
    .woocommerce button.button.alt:disabled, 
    .woocommerce button.button.alt:disabled:hover, 
    .woocommerce button.button.alt:disabled[disabled], 
    .woocommerce button.button.alt:disabled[disabled]:hover, 
    .woocommerce input.button.alt.disabled, 
    .woocommerce input.button.alt.disabled:hover, 
    .woocommerce input.button.alt:disabled, 
    .woocommerce input.button.alt:disabled:hover, 
    .woocommerce input.button.alt:disabled[disabled], 
    .woocommerce input.button.alt:disabled[disabled]:hover,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-handle
    .page-template-home-template .ht-main-navigation li:hover > a,
    .home.blog .ht-main-navigation li:hover > a,
    .page-template-home-template .ht-main-navigation .current > a,
    .home.blog .ht-main-navigation .current > a,
    .featured-post:before,
    #blog-box .blog-read-more a,
    main#innerpage-box .page-testimonial-box:hover,
    .woocommerce ul.products li.product:hover, .woocommerce-page ul.products li.product:hover, 
    main#innerpage-box .page-testimonial-box:hover .team-thumb img,
     #ht-masthead .header-social-links span:hover,
    .woocommerce ul.products li.product .button,
    div#sitemap-box h3:before,
    div#sitemap-box:before
    {
        border-color: {$primColor};
    }

    #ht-masthead,
    .woocommerce-error, 
    .woocommerce-info, 
    .woocommerce-message,
    div#sitemap-box{
        border-top-color: {$primColor};
    }

    .nav-next a:after{
        border-left-color: {$primColor};
    }
    blockquote{
        border-left-color: {$primColor} !important;
    }

    .nav-previous a:after{
        border-right-color: {$primColor};
    }

    .ht-active .ht-service-icon{
        box-shadow: 0px 0px 0px 2px #FFF, 0px 0px 0px 4px {$primColor};
    }

    .woocommerce ul.products li.product .onsale:after{
        border-color: transparent transparent {$darker_color} {$darker_color};
    }

    .woocommerce span.onsale:after{
        border-color: transparent {$darker_color} {$darker_color} transparent
    }
   

    @media screen and (max-width: 992px){
      header .nav-wrapper.show-menu{
            background:{$navigationrespnavbsbgssColor};
        }
        header nav .nav-title{
            color:{$navigationrespnavmenutitleColor};
        }
        header nav .nav-back:before{
            border-top-color:{$navigationrespnavmenutitleColor} !important;
        }
        header nav .nav-back:before{
            border-left-color:{$navigationrespnavmenutitleColor} !important;
        }
        header nav .nav-back:after{
            background-color:{$navigationrespnavmenutitleColor} !important;
        }
        header nav .nav-toggle{
            background-color:{$navigationrespnavmenutitlebgColor};
        }
        header nav li .submenu-icon i,
        header .nav-wrapper nav a, header .nav-wrapper nav ul.sub-menu a{
            color:{$navigationrespnavmenuColor} !important;
        }
        header .nav-wrapper nav{
            background-color:{$navigationrespnavmenubgColor};
        }
        header .js-nav-toggle{border-color: {$navigationrespnavtoggbarbgssColor} !important;}
        header .js-nav-toggle span, header .js-nav-toggle span::before, 
        header .js-nav-toggle span::after{background-color: {$navigationrespnavtoggbarbgssColor} ;}   
    }
    @media screen and (max-width: 991px){
    header.site-header,header .head-inn{ background:{$headerrespnavtoggbarheadbgclr } !important ; }
    header .Reg p, header .Reg li, header .Reg, header .head-inn a{ color:{$headerrespmailphoneColor } !important ; }
 }
}


";


    // heading text colour 
$headingColor = get_theme_mod('luzuk_title_color', '#fe5722');
$custom_css .= '.title-color{color:'.$headingColor.';}';

    // START SECONDARY COLOR CSS
$secondary = get_theme_mod('theme_secondary_color', '#f7f7f5');
$custom_css .='
.secondry-bg,
   #commentsAdd input[type="submit"]:hover,
input[type="button"]:hover, 
input[type="reset"]:hover, 
input[type="submit"]:hover,
div#secondary input[type="submit"]:hover,
.socialMedia a,
section#inner-blog-section .readMore,
.woocommerce ul.products li.product .button:hover,
.woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li, section#inner-blog-section h2.title,
.woocommerce #respond input#submit:hover,
.woocommerce a.button:hover, 
.woocommerce button.button:hover, 
.woocommerce input.button:hover,
div#content-box .wc-proceed-to-checkout a:hover,
.woocommerce #payment #place_order:hover, 
.woocommerce-page #payment #place_order:hover,
.woocommerce div.product form.cart .button:hover,
.single-productpage #sidebars button:hover,
.entry-readmore a:hover,

main#innerpage-box .ht-blog-thumbnail a:after{
    background-color:'.$secondary.'
}    
    #blog-box .blog-read-more a:hover,
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
.socialMedia a:hover,
.woocommerce ul.products li.product .button:hover,
.woocommerce #respond input#submit:hover,
.woocommerce a.button:hover, 
.woocommerce button.button:hover, 
.woocommerce input.button:hover,
div#content-box .wc-proceed-to-checkout a:hover,
.woocommerce #payment #place_order:hover, 
.woocommerce-page #payment #place_order:hover 
{border-color: '.$secondary.';}

main#innerpage-box #blog-box h2, 
main#innerpage-box #blog-box h2 small,
div#secondary .social-profile-icons ul li i:hover{color:'.$secondary.';}  

.woocommerce-MyAccount-navigation-link.is-active a {color:'.$secondary.' !important;}    


.product_list_widget .amount,
.product_list_widget del .amount,
.woocommerce ul.products li.product .total-product-title-wrap small,
.total-product-title-wrap,
div#content-box p a:hover,
div#content-box .woocommerce-info a:hover,
section#inner-blog-section h2.title:hover small,
.woocommerce .widget_rating_filter ul li a:hover span,
.woocommerce .star-rating:hover, 
.woocommerce-page .star-rating:hover span,
.woocommerce ul.products li.product .price del,
 .ht-site-title a, .site-title a,
.widget-area del span.woocommerce-Price-amount.amount
{color: '.$secondary.';}

';

 // header menus
$HeadertopmenusColorColor = get_theme_mod('header_topmenusColor', '#000');
$HeadertopmenusarrowColorColor = get_theme_mod('header_topmenusarrowColor', '#000');
$HeadertopmenushoverColorColor = get_theme_mod('header_topmenushoverColor', '#fff');
$HeadertopmenusactiveColorColor = get_theme_mod('header_topmenusactiveColor', '#fff');

$HeadertopsubmenusColor = get_theme_mod('header_topsubmenusColor', '#ffffff');
$headertopsubmenushvClr = get_theme_mod('header_topsubmenushvColor', '#f7c605');

$navigationrestopsubmenudropdownbgColor = get_theme_mod( 'header_submenusbgsscColor', '#000' );
$HeaderSiteTaglineColor = get_theme_mod( 'header_SiteTaglineColor', '#000' );
$HeaderSiteColor = get_theme_mod( 'header_SiteColor', '#000' );

$HeaderbgColorColor = get_theme_mod('header_bgColor', '#fff');
$headeralbgColor = get_theme_mod('header_albgColor', '#f7c605');

$HeadermailphoneColor = get_theme_mod('header_mailphoneColor', '#fff');
$headermailphonehvClr = get_theme_mod('header_mailphonehvClr', '#f7c605');
$headermailicnClr = get_theme_mod('header_mailicnClr', '#f7c605');
$headertpmailbgClr = get_theme_mod('header_tpmailbgClr', '#000');

    $custom_css .= '

.navigation .mainmenu li a{color: '.$HeadertopmenusColorColor.';}
.navigation .mainmenu>li.menu-item-has-children>a:after{color: '.$HeadertopmenusarrowColorColor.';}

.navigation .mainmenu li a:hover,
div#navbarNavDropdown li.current_page_item a:hover, .current_page_item > a:hover,
.navigation .mainmenu li.current_page_item a:hover, .current_page_item > a:hover
    {color: '.$HeadertopmenushoverColorColor.';}

.navigation .mainmenu li.current_page_item a, 
.current_page_item > a{color: '.$HeadertopmenusactiveColorColor.';}

header.site-header ul.sub-menu li a,
.header.site-header ul.sub-menu li a{color: '.$HeadertopsubmenusColor.';}
.header.site-header ul.sub-menu li a:hover{color: '.$headertopsubmenushvClr.';}

header.site-header ul.sub-menu li a:hover,
.navigation .mainmenu ul.sub-menu li.current_page_item a, 
div#navbarNavDropdown ul.sub-menu li.current_page_item a:hover,


ul.sub-menu, header.site-header ul.sub-menu,
ul.sub-menu:before,ul.sub-menu:after{background-color: '.$navigationrestopsubmenudropdownbgColor.';}

.ht-site-description a{color: '.$HeaderSiteTaglineColor.';}
.ht-site-title a{color: '.$HeaderSiteColor.';}

header .logo,header .lasthead{background-color: '.$HeaderbgColorColor.';}
header.site-header{background-color: '.$headeralbgColor.';}

header .Reg p,header .Reg li,header .Reg,
header .head-inn a{color: '.$HeadermailphoneColor.';}
header .head-inn a:hover{color: '.$headermailphonehvClr.';}
header .head-inn i{color: '.$headermailicnClr.';}
header .head-inn{background-color: '.$headertpmailbgClr.';}

';

      // slider color

$slidersecbxClr = get_theme_mod('slider_secbxClr', '#fff');
$slidersubtitleColor = get_theme_mod('slider_SubtitleColor', '#fff');
$sliderTitleColor = get_theme_mod('slider_titleColor', '#fff');
$slidersgradcolor = get_theme_mod('slider_bg_color', '#000');

$sliderButtontextcolor = get_theme_mod('slider_ButtontextColor', '#000');
$sliderButtontexthovercolor = get_theme_mod('slider_ButtontexthoverColor', '#f7c605');
$sliderButtonibrd = get_theme_mod('slider_Buttonibrd', '#f7c605');
$sliderButtonihv = get_theme_mod('slider_Buttonihv', '#fff');

$slibtnbgclr = get_theme_mod('sli_btnbgclr', '#5c5b5b');
$slibtnbghvclr = get_theme_mod('sli_btnbghvclr', '#f7c605');
$slibtnarowclr = get_theme_mod('sli_btnarowclr', '#f7c605');
$slibtnarowhvclr = get_theme_mod('sli_btnarowhvclr', '#000');


$custom_css .= '.slider_section .title, .slider_section .title small {color: '.$sliderTitleColor.';}

.slider_section .sub-title, 
.slider_section .sub-title small{color: '.$slidersubtitleColor.';}
.slider_gradiant{background-color: '.$slidersgradcolor.';}
.slider_section .btn5 a{color: '.$sliderButtontextcolor.';}
.slider_section .btn5 a:hover{color: '.$sliderButtontexthovercolor.';}

.slider_section .btn5 a{background-color: '.$sliderButtonibrd.';}

.slider_section .btn5 a:after,
.slider_section .btn5 a:before{background-color: '.$sliderButtonihv.';}

.slider_section .owl-nav .owl-prev, 
.slider_section .owl-nav .owl-next{background-color: '.$slibtnbgclr.' !important}

.slider_section .owl-nav .owl-prev:hover, 
.slider_section .owl-nav .owl-next:hover{background-color: '.$slibtnbghvclr.' !important}

.slider_section .owl-nav .owl-prev span, 
.slider_section .owl-nav .owl-next span{color: '.$slibtnarowclr.' }

.slider_section .owl-nav .owl-prev:hover span, 
.slider_section .owl-nav .owl-next:hover span{color: '.$slibtnarowhvclr.' }
';

    // services
if(get_theme_mod('luzuk_premium_service_section_background','off') == 'on' ){

    $bgimg = get_theme_mod('luzuk_service_bg_image');
    $img = !empty($bgimg)?$bgimg:get_template_directory_uri().'/images/default-gray.png';

    $custom_css .= 'div#service{background-image: url("'.$img.'");background-position: top;background-size: cover;background-attachment: fixed;}';
}else{
    $color = get_theme_mod('luzuk_service_bg_color', '#fff');
    if('#fff' != $color){
        $custom_css .= 'div#service {background-color: '.$color.';}';
    }
}

// services colors

$servicestitleclr = get_theme_mod('services_titleclr', '#000');
$servicestitlebrdclr = get_theme_mod('services_titlebrdclr', '#f7c605');

$servicesSimghvclr = get_theme_mod('services_Simghvclr', '#fff');
$ServicePageSbxColor = get_theme_mod('services_Sbxclr', '#fff');
$ServicePageTitleColor = get_theme_mod('services_ServicePageTitleColor', '#000');
$ServicePageTitlehvColor = get_theme_mod('services_ServicePageTitlehvColor', '#f7c605');
$servicetxtClr = get_theme_mod('service_txtClr', '#484848');

$servicebtntxtClr = get_theme_mod('service_btntxtClr', '#f7c605');
$servicebtntxthvClr = get_theme_mod('service_btntxthvClr', '#000');
$servicebtnbgClr = get_theme_mod('service_btnbgClr', '#fff');
$servicebtnbghvClr = get_theme_mod('service_btnbghvClr', '#f7c605');

$custom_css .= '

.service-area .section-title h2 , 
.service-area .section-title h2 small{color: '.$servicestitleclr.';}
.service-area .section-title h2:after{border-color: '.$servicestitlebrdclr.';}

.service-area .single-service-bx .service-title-box h4, 
.service-area .single-service-bx .service-title-box h4 small{color: '.$ServicePageTitleColor.';}
.service-area .single-service .ser-olay{background-image: linear-gradient(to top, transparent 0%, '.$servicesSimghvclr.' 100%);}

.service-area .service-title-box{background-color: '.$ServicePageSbxColor.';}

.service-area .single-service-bx:hover .service-title-box h4, 
.service-area .single-service-bx:hover .service-title-box h4 small{color: '.$ServicePageTitlehvColor.';}
.service-area .single-service-bx p{color: '.$servicetxtClr.';}

.service-area .btn5 a{color: '.$servicebtntxtClr.';}
.service-area .btn5 a:hover{color: '.$servicebtntxthvClr.';}
.service-area .btn5 a{background-color: '.$servicebtnbgClr.';}
.service-area .btn5 a:after,
.service-area .btn5 a:before{background-color: '.$servicebtnbghvClr.';}

';

// Services page:

$InnerSerimghvColor = get_theme_mod('luzuk_InnerSerimghvColor', '#fff');
$InnerServiceTextColor = get_theme_mod('luzuk_InnerServiceTextColor', '#fff');
$InnerServiceTexthvColor = get_theme_mod('luzuk_InnerServiceTexthvColor', '#f7c605');
$InnerServiceTitleColor = get_theme_mod('luzuk_InnerServiceTitleColor', '#131313');
$InnerSerTitlehvColor = get_theme_mod('InnerSerTitlehvColor', '#fff');

    $custom_css .= '

#innerpage-box .service-title-box .inner-area-title{color: '. $InnerServiceTitleColor.'!important;}
#innerpage-box .service-title-box .inner-area-title:hover{color: '. $InnerSerTitlehvColor.'!important;}
#innerpage-box .single-service .ovrly{ background-image: linear-gradient(to top, transparent 0%, '. $InnerSerimghvColor.' 100%);}
#innerpage-box .service-title-box{background-color: '. $InnerServiceTextColor.';}
#innerpage-box .single-service:hover .service-title-box{background-color: '. $InnerServiceTexthvColor.';}
#innerpage-box .service-title-box:before{border-bottom-color: '. $InnerServiceTexthvColor.';}
    
';

//colors
$InnerTeambrdColor = get_theme_mod('pages_InnerTeambrdColor', '#ccc');
$InnerTeamNameCColor = get_theme_mod('pages_InnerTeamNameCColor', '#131313');
$InnerTeamTeamDesignationColor = get_theme_mod('pages_InnerTeamDesignationCColor', '#f7c605');
$InnerteamareaHighlightboxOne = get_theme_mod('Innerteamarea_Highlightbox_color_one', '#fff');

$InnerTeamsllexClr = get_theme_mod('pages_InnerTeamsllexClr', '#000');
$InnerTeamsllextxtClr = get_theme_mod('pages_InnerTeamsllextxtClr', '#9a9595');

$InnerTeamsocialssbxClr = get_theme_mod('pages_InnerTeamsocialsbxClr', '#f7c605');
$InnerTeamsocialssColor = get_theme_mod('pages_InnerTeamsocialsColor', '#fff');
$InnerTeamsocialshoverColor = get_theme_mod('pages_TeamsocialshvrsColor', '#fff');

$custom_css .= 'body.page-template-default main#innerpage-box .inner-area-title, body.page-template-default main#innerpage-box .inner-area-title small{color: '.$InnerTeamNameCColor.';}

#innerpage-box .teaminn-page, 
#innerpage-box .teaminn-page .team-brdbx{border-color: '.$InnerTeambrdColor.';}

body.page-template-default main#innerpage-box .team-text .team-designation{color: '.$InnerTeamTeamDesignationColor.';}

#innerpage-box .team-con h5,
#innerpage-box .team-con h5 small{color: '.$InnerTeamsllexClr.'!important;}
#innerpage-box .teaminn-page p.t-skill{color: '.$InnerTeamsllextxtClr.';}

#innerpage-box .teaminn-page .team-social-icon{background-color: '.$InnerTeamsocialssbxClr.';}

body.page-template-default main#innerpage-box .team-social-icon a i{color: '.$InnerTeamsocialssColor.';}

body.page-template-default main#innerpage-box .team-social-icon a:hover i{color: '.$InnerTeamsocialshoverColor.';}

#innerpage-box .teaminn-page{background-color: '.$InnerteamareaHighlightboxOne.';}
';

//colors
$innerTsbximgbrdColor = get_theme_mod('luzuk_innertestimonials_imgbrdclr', '#f7c605');
$innerTsbxbrdColor = get_theme_mod('luzuk_innertestimonials_bxbrdclr', '#fff');
$innerTsNameColor = get_theme_mod('luzuk_innertestimonials_Namecolor', '#000');
$innerTstextColor = get_theme_mod('luzuk_innertestimonials_textcolor', '#000');
$innerTsicnColor = get_theme_mod('luzuk_innertestimonials_icncolor', '#f7c605');
$innerTsBoxpostionColor = get_theme_mod('luzuk_innertestimonials_postioncolor', '#444');
$custom_css .= '

#innerpage-box .ts-area-thumb:after{background-color: '.$innerTsbximgbrdColor.';}
#innerpage-box .ts-area-c{background-color: '.$innerTsbxbrdColor.';}
#innerpage-box .ts-area-c p{color: '.$innerTstextColor.';}
#innerpage-box .ts-img i{color: '.$innerTsicnColor.';}
#innerpage-box h3.ts-area-title, #innerpage-box h3.ts-area-title small{color: '.$innerTsNameColor.';}
#innerpage-box .innertest-item .text-designation{color: '.$innerTsBoxpostionColor.';}


';

// About bg
       if(get_theme_mod('luzuk_premium_about_section_background','off') == 'on' ){
        
        $bgimg = get_theme_mod('luzuk_about_bg_image');
        $img = !empty($bgimg)?$bgimg:get_template_directory_uri().'/images/default-gray.png';
        
        $custom_css .= '#about{background-image: url("'.$img.'");background-position: top;background-size: cover; background-repeat: no-repeat;}';
    }else{
        $color = get_theme_mod('luzuk_about_bg_color', '#f9f9f9');
        if('#f9f9f9' != $color){
            $custom_css .= '#about{background-color: '.$color.';}';
        }
    }

    // ENDS SECONDARY COLOR CSS

$aboutareasecsubtitle = get_theme_mod('about_area_secsubtitle_color', '#000');
$aboutareasecsubtitlebrd = get_theme_mod('about_area_secsubtitlebrd_clr', '#f7c605');
$aboutareasectitle = get_theme_mod('about_area_sectitle_color', '#000');
$aboutarea_TextColor = get_theme_mod('about_area_text', '#7a7878');
$aboutarea_pageiconColor = get_theme_mod('about_area_pageicon', '#f7c605');
$aboutarea_pagetitleColor = get_theme_mod('about_area_pagetitle', '#7a7878');
$aboutarea_pagetrxtColor = get_theme_mod('about_area_pagetext', '#7a7878');

$aboutabtntext = get_theme_mod('about_abtntext', '#000');
$aboutabtntexthv = get_theme_mod('about_abtntexthv', '#f7c605');
$aboutabtntextbg = get_theme_mod('about_abtntextbg', '#f7c605');
$aboutabtntextbghv = get_theme_mod('about_abtntextbghv', '#000');

$aboutareasimgbrd = get_theme_mod('about_area_simgbrd_color', '#f7c605');

$custom_css .= ' 

#about .sec-sub-title{color: '.$aboutareasecsubtitle.';}
#about .sec-sub-title:after{border-color: '.$aboutareasecsubtitlebrd.';}
#about .section-title h2, #about .section-title h2 small{color: '.$aboutareasectitle.';}
#about .htext{color: '.$aboutarea_TextColor.';}

#about .section-text-list li{color: '.$aboutarea_pagetitleColor.';}
#about .about-area-data p{color: '.$aboutarea_pagetrxtColor.';}
#about .section-text-list li:before{color: '.$aboutarea_pageiconColor.';}

#about .about-btn a{color: '.$aboutabtntext.';}
#about .about-btn a:hover{color: '.$aboutabtntexthv.';}
#about .about-btn a{background-color: '.$aboutabtntextbg.';}
#about .about-btn a:after,
#about .about-btn a:before{background-color: '.$aboutabtntextbghv.';}

#about .abt-imgbrd:before{border-color: '.$aboutareasimgbrd.';}

';

    // For Footer

if(get_theme_mod('luzuk_premium_footer_section_background','off') == 'on' ){

    $bgimg = get_theme_mod('luzuk_footer_bg_image');
    $img = !empty($bgimg)?$bgimg:get_template_directory_uri().'/images/default-gray.png';

    $custom_css .= '.footer-area{background-image: url("'.$img.'");background-position: top;background-size: cover;}';
}else{
    $color = get_theme_mod('luzuk_footer_bg_color', '#33393f');
    if('#33393f' != $color){
        $custom_css .= '.footer-area{background-color: '.$color.';}';
    }
}
// colors

$FooterAreaTitleColor = get_theme_mod('footerarea_title_color', '#fff');
$FooterAreaTextColor = get_theme_mod('footerarea_text_color', '#e1e0e0');
$FooterAreasiconColor = get_theme_mod('footerarea_sicon_color', '#7f7c7c');
$footerareasiconbrd = get_theme_mod('footerarea_siconbrd', '#7f7c7c');
$FooterAreasiconhoverColor = get_theme_mod('footerarea_siconhover_color', '#f7c605');

$FooterAreamenuColor = get_theme_mod('footerarea_menu_color', '#fff');
$FooterAreadatextColor = get_theme_mod('footerarea_datext_color', '#fff');

$FooterAreaformtextColor = get_theme_mod('footerarea_formtext_color', '#585858');
$footerareaformtxtbgclr = get_theme_mod('footerarea_formtxtbg_clr', '#f6f6f6');
$FootermenuhoverColor = get_theme_mod('footerarea_menuhover_color', '#f7c605');
$FooteractivemenuColor = get_theme_mod('footerarea_activemenu_color', '#f7c605');
$FooterformtextlabelColor = get_theme_mod('footerarea_formtextlabel_color', '#000');
$footerareaformtbgclr = get_theme_mod('footerarea_formtbg_color', '#000');
$footerareabuttontxtclr = get_theme_mod('footerareabutton_txt_color', '#000');
$footerareabuttonbgColor = get_theme_mod('footerareabutton_bg_color', '#f7c605');

$footerareabuttonButtonborderhoverColor = get_theme_mod('footerareabutton_borderhover_color', '#222225');
$footerareabuttonbghoverColor = get_theme_mod('footerareabutton_bghover_color', '#5c5a5b');

$footerNewslettertitleclr = get_theme_mod('footer_Newslettertitleclr', '#fff');

$footerareaphbgclr = get_theme_mod('footerarea_phbgclr', '#f7c605');
$footerareacopyrightColor = get_theme_mod('footerarea_copyright_color', '#000');
$footerareacopyrighticnhvclr = get_theme_mod('footerarea_copyrighticnhv_clr', '#b5b3b3');
$footerareabtmbgclr = get_theme_mod('footerarea_btmbgclr', '#fff');


$custom_css .= '


footer#footer.footer-area .widget-title {color: '.$FooterAreaTitleColor.';}
.footer-area p, 
.footer-area caption, 
.footer-area li, 
.footer-area table td, 
.footer-area input[type="submit"], 
.footer_facility-text, 
.footer-area .textwidget{color: '.$FooterAreaTextColor.';}

.footer-area .social-profile-icons ul li a i,
.footer-area .footer-social-links a{color: '.$FooterAreasiconColor.';}

.footer-area .social-profile-icons ul li{border-color: '.$footerareasiconbrd.';}

.footer-area .social-profile-icons ul li:hover i.fa,
.footer-area .footer-social-links li:hover i{color: '.$FooterAreasiconhoverColor.';}

.footer-area li a,
.footer-area .tagcloud a,
.footer-area li:before{color: '.$FooterAreamenuColor.';}


.footer-area span.post-date, .footer-area .widget_calendar table tbody td, .footer-area .widget_calendar table tbody td a, .footer-area .widget_calendar table tbody td#today a{color: '.$FooterAreadatextColor.';}

.footer-area input[type="text"]::placeholder, .footer-area input[type="email"]::placeholder, .footer-area input[type="url"]::placeholder, .footer-area input[type="password"]::placeholder, .footer-area input[type="search"]::placeholder, .footer-area input[type="number"]::placeholder, .footer-area input[type="tel"]::placeholder, .footer-area input[type="range"]::placeholder, .footer-area input[type="date"]::placeholder, .footer-area input[type="month"]::placeholder, .footer-area input[type="week"]::placeholder, .footer-area input[type="time"]::placeholder, .footer-area input[type="datetime"]::placeholder, .footer-area input[type="datetime-local"]::placeholder, .footer-area input[type="color"]::placeholder, .footer-area textarea::placeholder,
.footer-area input[type="text"], .footer-area input[type="email"], .footer-area input[type="url"], .footer-area input[type="password"], .footer-area input[type="search"], .footer-area input[type="number"], .footer-area input[type="tel"], .footer-area input[type="range"], .footer-area input[type="date"], .footer-area input[type="month"], .footer-area input[type="week"], .footer-area input[type="time"], .footer-area input[type="datetime"], .footer-area input[type="datetime-local"], .footer-area input[type="color"], .footer-area textarea, .footer-area select, .footer-area .widget.widget_categories select{color: '.$FooterAreaformtextColor.';}

.footer-area input[type="text"], .footer-area input[type="email"], .footer-area input[type="url"], .footer-area input[type="password"], .footer-area input[type="search"], .footer-area input[type="number"], .footer-area input[type="tel"], .footer-area input[type="range"], .footer-area input[type="date"], .footer-area input[type="month"], .footer-area input[type="week"], .footer-area input[type="time"], .footer-area input[type="datetime"], .footer-area input[type="datetime-local"], .footer-area input[type="color"], .footer-area textarea, .footer-area select{background-color: '.$footerareaformtxtbgclr.';}

.footer-area li a:hover, .footer-area li:hover:before{color: '.$FootermenuhoverColor.';}

.footer-area li.current_page_item a, .footer-area li.current_page_item:before{color: '.$FooteractivemenuColor.';}
footer#footer label span, .footer-area div.wpcf7 input[type="file"], .footer-area .widget_calendar table thead tr th,
footer#footer div.wpcf7 p{color: '.$FooterformtextlabelColor.';}

.newsletter{background-color: '.$footerareaformtbgclr.';}

.footer-area .wpcf7:after{color: '.$footerareabuttontxtclr.';}
.footer-area input[type="submit"]{background-color: '.$footerareabuttonbgColor.';}
.footer-area input[type="submit"]:hover{background-color: '.$footerareabuttonbghoverColor.';}

.newsletter h5,.newsletter h5 small{color: '.$footerNewslettertitleclr.';}

.footer-area .fbox1{background-color: '.$footerareaphbgclr.';}
.footer-text, .footer-text a,
.footer-area .f-contact-inn,
.footer-area .f-contact-inn a,
.footer-area .f-contact-inn i{color: '.$footerareacopyrightColor.';}

.footer-area .f-contact i,
.footer-area .f-contact-inn li{border-color: '.$footerareacopyrightColor.';}
.footer-area .f-contact-inn a:hover{color: '.$footerareacopyrighticnhvclr.';}

.footer-area .bottom-area{background-color: '.$footerareabtmbgclr.';}

';

// inner page gallery colors

$luzukgallinnimghvbrdClr = get_theme_mod('luzuk_gallinnimghvbrdClr', '#f7c605');
$luzukgallinnimgbrdClr = get_theme_mod('luzuk_gallinnimgbrdClr', '#f7c605');

$custom_css .= '


#innerpage-box .spa-gall h3{color: '.$luzukgallinnimghvbrdClr.' !important;}

#innerpage-box .gall-icn i,
#innerpage-box .gall-icn i:hover{color: '.$luzukgallinnimgbrdClr.';}

';

// faq inner page colors

$faqinnerpagetitleColor = get_theme_mod('luzuk_faqinnerpagetitleColor', '#000');

$faqinnerpagetitlebrdColor = get_theme_mod('luzuk_faqinnerpagetitlebrdColor', '#ccc');
$faqinnerpagetitleIconColor = get_theme_mod('luzuk_faqinnerpagetitleIconColor', '#000');
$faqinnerpagetitleIconbgClr = get_theme_mod('luzuk_faqinnerpagetitleIconbgClr', '#f7c605');
$faqinnerpagetextcColor = get_theme_mod('luzuk_faqinnerpagetextcColor', '#444');
$faqinnerpageansbg1Color = get_theme_mod('luzuk_faqinnerpageansbg1Color', '#fff');
$faqinnerpageansbg2Color = get_theme_mod('luzuk_faqinnerpageansbg2Color', '#fff');

$custom_css .= 'main#innerpage-box div#content-box h3.faq-title,
main#innerpage-box div#content-box h3.faq-title small{color: '.$faqinnerpagetitleColor.';}

#content-box .faq-content{border-color: '.$faqinnerpagetitlebrdColor.';}
#content-box .faq-content button.accordion:before{color: '.$faqinnerpagetitleIconColor.';}
#content-box .faq-content button.accordion:before{background-color: '.$faqinnerpagetitleIconbgClr.';}
#content-box .faq-content p{color: '.$faqinnerpagetextcColor.';}

#content-box .faq-content div.panel {
    background: linear-gradient(0deg,'.$faqinnerpageansbg1Color.','.$faqinnerpageansbg2Color.' 80%) no-repeat;}

';

       //Inner page title color
$innerheaderolyColor = get_theme_mod('luzuk_template_innerpage_headeolyclr', '#000');

$innertitleColor = get_theme_mod('luzuk_template_innerpage_titlecolor', '#fff');

$innertitlebgColor1 = get_theme_mod('luzuk_template_innerpage_bgcolor1', '#ccc');

$innertitlebgColor2 = get_theme_mod('luzuk_template_innerpage_bgcolor2', '#0a0607');

$innerbreadcrumbtitleColor = get_theme_mod('luzuk_template_innerpage_breadcrumbtitlecolor', '#fff');

$innerbreadcrumbcurrenttitleColor = get_theme_mod('luzuk_template_innerpage_breadcrumbcurrenttitlecolor', '#fff');

$innerbreadcrumbcurrenttitlehovercolor = get_theme_mod('luzuk_template_innerpage_breadcrumbcurrenttitlehovercolor', '#f7c605');

$innerbreadcrumbcurrenttitlepagecolor = get_theme_mod('luzuk_template_innerpage_breadcrumbcurrenttitlepageclr', '#f7c605');

$innerbreadcrumbbgbackttoparrcbgbgcolor = get_theme_mod('luzuk_template_innerpage_backttoparrcbgbgcolor', '#000');

$innerbreadcrumbbgbackttoparrcbgcolorcolor = get_theme_mod('luzuk_template_innerpage_backttoparrcbgcolor', '#f7c605');

$innerbreadcrumbbgbackttoparrbackcolbgcolor = get_theme_mod('luzuk_template_innerpage_backttoparrbackcolbgcolor', '#fd3e1c');

$innerbreadcrumbbgbackttoparrcbghvrcolor = get_theme_mod('luzuk_template_innerpage_backttoparrcbghvrcolor', '#3e454b');

$innerbreadcrumbbgbackttoparrbackcolbghvrscolor = get_theme_mod('luzuk_template_innerpage_backttoparrbackcolbghvrscolor', '#ffffff');

$custom_css .= '.ht-main-title, .single-productpage .ht-main-title,
    .ht-main-title small {color: '.$innertitleColor.';}

.page-main-header .overlay1{background-color: '.$innerheaderolyColor.';}

.page-main-header {
        background: linear-gradient(0deg,'.$innertitlebgColor1.','.$innertitlebgColor2.' 80%) no-repeat;
    }
.breadcrumbbox span, .woocommerce .woocommerce-breadcrumb{color: '.$innerbreadcrumbtitleColor.';}
.breadcrumbbox span a , .woocommerce .woocommerce-breadcrumb a{color: '.$innerbreadcrumbcurrenttitleColor.';}
.breadcrumbbox span a:hover, #content-box .breadcrumbbox span a:hover, .woocommerce .woocommerce-breadcrumb a:hover{color: '.$innerbreadcrumbcurrenttitlehovercolor.';}

.breadcrumbbox span.treeEnd{background-color: '.$innerbreadcrumbcurrenttitlepagecolor.';}

#back2Top{background-color: '.$innerbreadcrumbbgbackttoparrcbgbgcolor.';}

#back2Top{color: '.$innerbreadcrumbbgbackttoparrcbgcolorcolor.';}
#back2Top:hover{color: '.$innerbreadcrumbbgbackttoparrcbghvrcolor.';}';

$headerinnerpagemaininnerpagemainsectionboxsectionboxColor = get_theme_mod('luzuk_template_innerpagemainsectionbox_color', '#ffffff');
$innerpagemainsectioninnerpagemainsectionboxheading1 = get_theme_mod('luzuk_template_innerpagemainsectionboxheading1_color', '#121a36');
$innerpagemainsectioninnerpagemainsectionboxheading2 = get_theme_mod('luzuk_template_innerpagemainsectionboxheading2_color', '#121a36');
$innerpagemainsectioninnerpagemainsectionboxheading3 = get_theme_mod('luzuk_template_innerpagemainsectionboxheading3_color', '#121a36');
$innerpagemainsectioninnerpagemainsectionboxheading4 = get_theme_mod('luzuk_template_innerpagemainsectionboxheading4_color', '#121a36');
$innerpagemainsectioninnerpagemainsectionboxheading5 = get_theme_mod('luzuk_template_innerpagemainsectionboxheading5_color', '#121a36');
$innerpagemainsectioninnerpagemainsectionboxheading6 = get_theme_mod('luzuk_template_innerpagemainsectionboxheading6_color', '#121a36');

$innerpagemainsectioninnerpagemainsectionboxheadingborderc1 = get_theme_mod('innerpagemainsectioninnerpagemainsectionboxheadingborderc1', '#f7c605');

$innerpagesidebartitleColor = get_theme_mod('template_innerpage_contentboxsidebartitlecolor', '#676767');
$innerpagesidebartitleborderColor = get_theme_mod('template_innerpage_contentboxsidebartitlebordercolor', '#f7c605');

$innerproductpageboldtextColor = get_theme_mod('template_innerpage_productpageboldtextcolor', '#000');

$innercartpageproducttitleColor = get_theme_mod('template_innerpage_cartpageproducttitlecolor', '#000');


$headerinnerpagemainsectionboxtextColor = get_theme_mod('luzuk_template_innerpagemainsectionboxtext_color', '#666');
$innerpagemainsectionboxtextlinksColor = get_theme_mod('luzuk_template_innerpagemainsectionboxtextlinks_color', '#666');
$innerpagemainsectionboxtextlinkshoverColor = get_theme_mod('luzuk_template_innerpagemainsectionboxtextlinkshvrs_color', '#131313');
$innerpagemainsectionboxtextlinksiconColor = get_theme_mod('luzuk_template_innerpagemainsectionboxtextlinksicon_color', '#000');
$innerpagemainsectionboxtextlinksiconbgssclrlinksiconColor = get_theme_mod('luzuk_template_innerpagemainsectionboxtextlinksiconbgssclr_color', '#b5b1b3');

$headerinnerpageproductpriceColor = get_theme_mod('luzuk_template_innerpageproductprice_color', '#f7c605');
$headerinnerpageproductpricedelColor = get_theme_mod('luzuk_template_innerpageproductpricedel_color', '#7c8491');
$headerinnerpageproductimghovericonColor = get_theme_mod('luzuk_template_innerpageproductimghovericon_color', '#cfd0d5');
$headerinnerpageproductimghovericonbgColor = get_theme_mod('luzuk_template_innerpageproductimghovericonbg_color', '#fff');
$headerinnerpagepaginationColor = get_theme_mod('luzuk_template_innerpagepagination_color', '#000');
$headerinnerpagepaginationbgColor = get_theme_mod('luzuk_template_innerpagepaginationbg_color', '#fff');
$headerinnerpagepaginationborderColor = get_theme_mod('luzuk_template_innerpagepaginationborder_color', '#eaeaea');

$headerinnerpagepaginationactiveColor = get_theme_mod('luzuk_template_innerpagepaginationactive_color', '#fff');
$headerinnerpagepaginationbgactiveColor = get_theme_mod('luzuk_template_innerpagepaginationbgactive_color', '#f7c605');
$headerinnerpagepaginationborderactiveColor = get_theme_mod('luzuk_template_innerpagepaginationborderactive_color', '#f7c605');

$innerpageblogcontainbgclr = get_theme_mod('luzuk_template_innerpage_blogcontainbgclr', '#fff');
$innerpageblogdateathorcolor = get_theme_mod('luzuk_template_innerpage_blogdateathorclr', '#f7c605');
$innerpageblogdateathoricnclr = get_theme_mod('luzuk_template_innerpage_blogdateathoricnclr', '#000');
$innerpageblogtitlecolor = get_theme_mod('luzuk_template_innerpage_blogtitlecolor', '#3d3d3d');
$innerpageblogtitlehovercolor = get_theme_mod('luzuk_template_innerpage_blogtitlehovercolor', '#f7c605');

$innerpageblogtextcolor = get_theme_mod('luzuk_template_innerpage_blogtitxtcolor', '#757575');

$innerpageblogsocialColors = get_theme_mod('luzuk_template_innerpage_blogsocialcolor', '#fff');
$innerpageblogsocialbgColors = get_theme_mod('luzuk_template_innerpage_blogsocialbgcolor', '#f7c605');
$innerpageblogsocialhoverColors = get_theme_mod('luzuk_template_innerpage_blogsocialhovercolor', '#fff');
$innerpageblogsocialbghoverColors = get_theme_mod('luzuk_template_innerpage_blogsocialbghovercolor', '#000');

$innerpageblogbtntxtClr = get_theme_mod('luzuk_template_innerpage_blogbtvtxtclr', '#fff');
$innerpageblogbtntxthvClr = get_theme_mod('luzuk_template_innerpage_blogbtvtxthvclr', '#000');
$innerpageblogbtnbgClr = get_theme_mod('luzuk_template_innerpage_blogbtvbgclr', '#000');
$innerpageblogbtnbghvClr = get_theme_mod('luzuk_template_innerpage_blogbtvbghvclr', '#f7c605');

$innerpageblogimgoverlaycolor1 = get_theme_mod('luzuk_template_innerpage_blogimgoverlaycolor1', '#3e454b');
$innerpageblogimgoverlaycolor2 = get_theme_mod('luzuk_template_innerpage_blogimgoverlaycolor2', '#f7c605');
$innerpagemainsectionsidebarbg = get_theme_mod('luzuk_template_innerpagemainsectionsidebarbg_color', '#f1f1f1');
$innerpagemainsectionsidebarborderrs = get_theme_mod('luzuk_template_innerpagemainsectionsidebarborderrs_color', '#e4e2e2');
$innerpagesidebardaytxtColors = get_theme_mod('luzuk_template_innerpagesidebardaytxt_color', '#ffffff');
$innerpagesidebardaybgsstxtColors = get_theme_mod('luzuk_template_innerpagesidebardaybgsstxt_color', '#f7c605');
$innerpageblockquoteColors = get_theme_mod('luzuk_template_innerpagesblockquote_color', '#f2f2f2');

$custom_css .= '#innerpage-box, .inner_contentbox {background-color: '.$headerinnerpagemaininnerpagemainsectionboxsectionboxColor.';}
body.page-template-default main#innerpage-box h1, 
.woocommerce div.product .product_title small,
.woocommerce div.product .product_title{color: '.$innerpagemainsectioninnerpagemainsectionboxheading1.';}

body.page-template-default main#innerpage-box h2,
main#innerpage-box h2 ,
main#innerpage-box h2 small,
main#innerpage-box h2 a, 
main#innerpage-box h2 a small,
.woocommerce #reviews h2 small{color: '.$innerpagemainsectioninnerpagemainsectionboxheading2.';}

main#innerpage-box h3{color: '.$innerpagemainsectioninnerpagemainsectionboxheading3.';}

body.page-template-default main#innerpage-box h4,
div#commentsAdd h4,
main#innerpage-box h4
{color: '.$innerpagemainsectioninnerpagemainsectionboxheading4.';}

main#innerpage-box h5,
body.page-template-default main#innerpage-box h5{color: '.$innerpagemainsectioninnerpagemainsectionboxheading5.';}

main#innerpage-box h6,
div#blog-box.innerpage-whitebox h6{color: '.$innerpagemainsectioninnerpagemainsectionboxheading6.';}

body.page-template-default main#innerpage-box h1:after, body.page-template-default main#innerpage-box h2:after, body.page-template-default main#innerpage-box h3:after, body.page-template-default main#innerpage-box h4:after, body.page-template-default main#innerpage-box h5:after, body.page-template-default main#innerpage-box h6:after, .page-template-templates main#innerpage-box h1:after, .page-template-templates main#innerpage-box h2:after, .page-template-templates main#innerpage-box h3:after, .page-template-templates main#innerpage-box h4:after, .page-template-templates main#innerpage-box h5:after, .page-template-templates main#innerpage-box h6:after{background-color: '.$innerpagemainsectioninnerpagemainsectionboxheadingborderc1.';}

.woocommerce ul.products li.product .price .amount{color: '.$headerinnerpageproductpriceColor.' !important;}
.woocommerce ul.products li.product .price del .amount, .widget-area del span.woocommerce-Price-amount.amount,
.woocommerce ul.products li.product .price del{color: '.$headerinnerpageproductpricedelColor.' !important;}

main#innerpage-box h2.woocommerce-loop-product__title:before, .woocommerce ul.products li.product .button:before{color: '.$headerinnerpageproductimghovericonColor.';}
main#innerpage-box h2.woocommerce-loop-product__title:before, .woocommerce ul.products li.product .button:before{background-color: '.$headerinnerpageproductimghovericonbgColor.';}

.woocommerce div.product .product_meta .posted_in, .woocommerce div.product .product_meta .tagged_as,
.woocommerce div.product .product_meta span.sku_wrapper {color: '.$innerproductpageboldtextColor.';}

div#content-box table.shop_table.shop_table_responsive.cart.woocommerce-cart-form__contents tr td a, .woocommerce div.product form.cart table.variations tr td label {color: '.$innercartpageproducttitleColor.';}

.woocommerce nav.woocommerce-pagination ul li a, .pagingation a{color: '.$headerinnerpagepaginationColor.';}
.woocommerce nav.woocommerce-pagination ul li a, .pagingation a{background-color: '.$headerinnerpagepaginationbgColor.';}
.woocommerce nav.woocommerce-pagination ul li a, .pagingation a{border-color: '.$headerinnerpagepaginationborderColor.';}

body.page-template-default main#innerpage-box h2, body.page-template-default main#innerpage-box h1, body.page-template-default main#innerpage-box h3, body.page-template-default main#innerpage-box h4, body.page-template-default main#innerpage-box h5, body.page-template-default main#innerpage-box h6, main#innerpage-box h2, #blog-box h4, h1.product_title.entry-title{border-bottom-color: '.$headerinnerpagepaginationborderColor.';}

.woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .pagingation .current, .pagingation a:hover,
.woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li span.current, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li span.current,
.woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce-page nav.woocommerce-pagination ul li a:hover, .woocommerce #content nav.woocommerce-pagination ul li a:hover, .woocommerce-page #content nav.woocommerce-pagination ul li a:hover
{color: '.$headerinnerpagepaginationactiveColor.';}
.woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .pagingation .current, .pagingation a:hover{background-color: '.$headerinnerpagepaginationbgactiveColor.';}
.woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .pagingation .current, .pagingation a:hover,
.woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li span.current, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li span.current,
.woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce-page nav.woocommerce-pagination ul li a:hover, .woocommerce #content nav.woocommerce-pagination ul li a:hover, .woocommerce-page #content nav.woocommerce-pagination ul li a:hover
{border-color: '.$headerinnerpagepaginationborderactiveColor.';}

   .widget-area h3.widget-title, 
    #blog-box .widget-area .widget-title,
   .widget-area .widget-title,
    main#innerpage-box h4.widget-title,
    main#innerpage-box h3.widget-title,
    #innerpage-box .widget-area .widget-title,
    .widget-area .widget h4
     {color: '.$innerpagesidebartitleColor.';}
      .widget-area .widget-title{border-color: '.$innerpagesidebartitleColor.';}

  .widget-area .widget-title,
    main#innerpage-box h4.widget-title,
    main#innerpage-box h3.widget-title{background-color: '.$innerpagesidebartitleborderColor.';}
body.page-template-default #innerpage-box .widget-area .widget-title:after, .page-template-templates #innerpage-box .widget-area .widget-title:after, .widget-area .widget h4:after{background-color: '.$innerpagesidebartitleborderColor.';}
    
        .widget-area .widget h4:after, .woocommerce div.product form.cart .button, .woocommerce-page div.product form.cart .button, .woocommerce #content div.product form.cart .button, .woocommerce-page #content div.product form.cart .button, .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li, .single-productpage #sidebars button:hover, .entry-readmore a:hover, 
.woocommerce ul.products li.product .button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, div#content-box .wc-proceed-to-checkout a:hover, .woocommerce #payment #place_order:hover, .woocommerce-page #payment #place_order:hover
        {background-color: '.$innerpagesidebartitleborderColor.' ;}


.woocommerce div.product .product_meta .posted_in, .woocommerce div.product .product_meta .tagged_as,
.woocommerce div.product .product_meta span.sku_wrapper {color: '.$innerproductpageboldtextColor.';}


#innerpage-box p, #content-box ul li, #content-box ol li, main#innerpage-box ul#recentcomments li, #blog-box .inner-blog-excerpt,
#secondary input[type="text"],
#secondary input[type="email"],
#secondary input[type="url"],
#secondary input[type="password"],
#secondary input[type="search"],
#secondary input[type="number"],
#secondary input[type="tel"],
#secondary input[type="range"],
#secondary input[type="date"], 
#secondary input[type="month"], 
#secondary input[type="week"], 
#secondary input[type="time"], 
#secondary input[type="datetime"], 
#secondary input[type="datetime-local"], 
#secondary input[type="color"], 
#secondary textarea, 
#secondary select,
#secondary label,
div#secondary select option,
#secondary input::placeholder,
#secondary textarea::placeholder,
#secondary select::placeholder,
#secondary input[type="file"],
    main#innerpage-box .widget_calendar table tbody td,
    main#innerpage-box li,
    div#secondary caption,
    .single_post .post-date-publishable,
    main#innerpage-box textarea#comment,
    .total-comments,
    .woocommerce .woocommerce-ordering select,
    .woocommerce-product-search .search-field::placeholder,
    table.shop_table.woocommerce-checkout-review-order-table,
    .woocommerce form .form-row .input-text::placeholder, 
    .woocommerce-page form .form-row .input-text::placeholder,
    .woocommerce form .form-row input.input-text::placeholder, 
    .woocommerce form .form-row textarea::placeholder,
    main#innerpage-box input#billing_email,
    .select2-container--default .select2-selection--single .select2-selection__rendered,
    div#content-box input#account_email,
    main#innerpage-box input#account_display_name,
    .widget.widget_categories select,
    main#innerpage-box .select2-container--default .select2-selection--single .select2-selection__placeholder,
    div#secondary select,
    main#innerpage-box .woocommerce-product-search .search-field,
    main#innerpage-box .woocommerce-product-search .search-field::placeholder,
    .woocommerce .woocommerce-result-count,
    .woocommerce .widget_price_filter .price_slider_amount,
    .select2-container--default .select2-results>.select2-results__options,
    .select2-results__option[aria-selected], 
    .select2-results__option[data-selected],
    .woocommerce #reviews #comments ol.commentlist li .comment-text p.meta, 
    .woocommerce-page #reviews #comments ol.commentlist li .comment-text p.meta,
    .comment-form-rating,
    .comment-respond .comment-reply-title,
    .woocommerce .product_meta,
    .woocommerce-error, 
    .woocommerce-info, 
    .woocommerce-message,
    .woocommerce-MyAccount-content address,
    .woocommerce-MyAccount-content legend,
    .woocommerce-MyAccount-content input[type="text"],
    .woocommerce table thead th,
    .woocommerce form .form-row input.input-text, 
    .woocommerce form .form-row textarea,
    .woocommerce table.shop_table td,
    .woocommerce .quantity .qty,
    input#coupon_code::placeholder,
    input#coupon_code,
    .woocommerce table.shop_table tbody th, 
    .error404 .oops-text{color: '.$headerinnerpagemainsectionboxtextColor.';}


    .price .amount{color: '.$headerinnerpagemainsectionboxtextColor.' !important;}

    .widget-area a, .woocommerce-MyAccount-navigation-link a, .entry-content p a, div#content-box a, div#sidebars span.product-title, div#sitemap-box ul li a, main#innerpage-box .woocommerce-info a.showcoupon,
    .woocommerce .product_meta a,
    .widget-area ul ul li a{color: '.$innerpagemainsectionboxtextlinksColor.';}

#content-box ul li:before, #content-box ol li:before,
    main#innerpage-box div#sitemap-box ul li a:before{color: '.$innerpagemainsectionboxtextlinksiconColor.';}
    
#content-box ol li:before{background-color: '.$innerpagemainsectionboxtextlinksiconbgssclrlinksiconColor.';}
    .widget-area a:hover, .woocommerce-MyAccount-navigation-link a:hover, .entry-content p a:hover, div#content-box a:hover, div#content-box a:hover small, div#sidebars span.product-title:hover, .widget-area li a:hover, div#content-box p a:hover, div#sitemap-box ul li a:hover, div#content-box a.shipping-calculator-button:hover, main#innerpage-box .woocommerce-info a.showcoupon:hover, div#content-box div#payment a.woocommerce-privacy-policy-link:hover, div#content-box .woocommerce-MyAccount-navigation-link a:hover,
    div#content-box a.post-edit-link:hover,
    div#content-box .woocommerce-MyAccount-content p a:hover,
    div#content-box a.shipping-calculator-button:hover,
    div#content-box div#payment a:hover,
    .woocommerce .product_meta a:hover{color: '.$innerpagemainsectionboxtextlinkshoverColor.';}


    .widget-area .widget,
#secondary input[type="text"],
    main#innerpage-box .woocommerce-product-search .search-field,
    .woocommerce form .form-row input.input-text, 
    .woocommerce form .form-row textarea,
    .select2-container--default .select2-selection--single,
#innerpage-box .comment-respond,
    main#innerpage-box div#commentsAdd textarea#comment,
    .widget.widget_categories select,
    div#secondary .select2-container--default .select2-selection--single,
    .single_post .post-date-publishable,
    div#secondary select,
    .single-productpage #sidebars button,
    .woocommerce .widget_shopping_cart .buttons a, 
    .woocommerce.widget_shopping_cart .buttons a,
    .woocommerce ul.cart_list li img, 
    .woocommerce-page ul.cart_list li img, 
    .woocommerce ul.product_list_widget li img, 
    .woocommerce-page ul.product_list_widget li img,
    .woocommerce .widget_shopping_cart .total, 
    .woocommerce.widget_shopping_cart .total,
    .woocommerce .products ul, 
    .woocommerce-page .products ul, 
    .woocommerce ul.products, 
    .woocommerce-page ul.products,
    .woocommerce-page .woocommerce-ordering select,
    .woocommerce div.product form.cart .button, 
    .woocommerce-page div.product form.cart .button, 
    .woocommerce #content div.product form.cart .button, 
    .woocommerce-page #content div.product form.cart .button,
    .woocommerce #review_form #respond textarea,
    .woocommerce #review_form #respond .form-submit input,
    .woocommerce table.shop_table,
    .woocommerce table.shop_table td,
    .woocommerce table.shop_table tbody th, 
    .woocommerce table.shop_table tfoot td, 
    .woocommerce table.shop_table tfoot th,
    .woocommerce-checkout #payment ul.payment_methods,
    .woocommerce .cart .button, 
    .woocommerce .cart input.button,
    .woocommerce-cart .cart-collaterals .cart_totals tr th,
    .woocommerce-cart .cart-collaterals .cart_totals tr td,
    .woocommerce-cart table.cart td.actions .coupon .input-text,
    input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], input[type="number"], input[type="tel"], input[type="range"], input[type="date"], input[type="month"], input[type="week"], input[type="time"], input[type="datetime"], input[type="datetime-local"], input[type="color"], textarea,

    .widget-area .widget, .woocommerce ul.products li.product a img, .widget-area ul, .widget-area .textwidget, .widget-area .woocommerce-product-search , .widget-area form#searchform, .widget-area .widget_rating_filter ul, .widget-area .woocommerce .widget_shopping_cart_content p, .widget-area div#calendar_wrap, .widget-area .widget_media_image img, .widget-area .tagcloud, 
    input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], input[type="number"], input[type="tel"], input[type="range"], input[type="date"], input[type="month"], input[type="week"], input[type="time"], input[type="datetime"], input[type="datetime-local"], input[type="color"], textarea,main#innerpage-box .widget-area .tagcloud a, 
    .woocommerce .woocommerce-widget-layered-nav-list,#secondary .gallery-columns-3{border-color: '.$innerpagemainsectionsidebarborderrs.'!important;;}

    .woocommerce table.shop_attributes th, .woocommerce table.shop_attributes td{border-bottom-color: '.$innerpagemainsectionsidebarborderrs.';}
    .woocommerce table.shop_attributes{border-top-color: '.$innerpagemainsectionsidebarborderrs.';}
       .woocommerce table.shop_attributes th, .woocommerce table.shop_attributes td,.woocommerce div.product .product_title, .woocommerce div.product form.cart, .woocommerce div.product .woocommerce-tabs ul.tabs, .widget-area li, .widget-area .widget h4, #innerpage-box .widget-area .widget-title{border-bottom-color: '.$innerpagemainsectionsidebarborderrs.';}
    
    .woocommerce table.shop_attributes, .woocommerce div.product form.cart, .woocommerce #content div.product .woocommerce-tabs, .woocommerce div.product .woocommerce-tabs, .woocommerce-page #content div.product .woocommerce-tabs, .woocommerce-page div.product .woocommerce-tabs{border-top-color: '.$innerpagemainsectionsidebarborderrs.';}

.widget-area .widget{background-color: '.$innerpagemainsectionsidebarbg.';}

.woocommerce ul.products li.product, 
.woocommerce-page ul.products li.product,
.woocommerce ul.products li.product a img,
.woocommerce div.product div.images img,
.quantity input[type="number"],
.woocommerce .products ul, 
.woocommerce-page .products ul, 
.woocommerce ul.products, 
.woocommerce-page ul.products{border-color: '.$innerpagemainsectionsidebarborderrs.' !important;}

div#secondary .widget_calendar table thead tr th, 
.pagination .page-numbers, .pagination .page-numbers:hover{color: '.$innerpagesidebardaytxtColors.';}

div#secondary .widget_calendar table thead tr th{background-color: '.$innerpagesidebardaybgsstxtColors.';}

blockquote{background-color: '.$innerpageblockquoteColors.';}

#innerpage-box .inner-blogpost .blog-date,
#innerpage-box .inner-blogpost .blog-date span i{color: '.$innerpageblogdateathoricnclr.';}

#innerpage-box .inner-blogpost-info{background-color: '.$innerpageblogcontainbgclr.';}

#innerpage-box .inner-blogpost .blog-date,#innerpage-box .inner-blogpost .blog-date span{color: '.$innerpageblogdateathorcolor.';}
main#innerpage-box #blog-box h2, main#innerpage-box #blog-box h2 small{color: '.$innerpageblogtitlecolor.';}   
main#innerpage-box #blog-box .inner-blogpost:hover h2, 
main#innerpage-box #blog-box .inner-blogpost:hover h2 small{color: '.$innerpageblogtitlehovercolor.';}  

main#innerpage-box #blog-box .inner-blog-excerpt{color: '.$innerpageblogtextcolor.';}  

.socialMedia ul li a.site-button, main#innerpage-box #blog-box .socialMedia ul li a.site-button{color: '.$innerpageblogsocialColors.';}
.socialMedia ul li a.site-button, main#innerpage-box #blog-box .socialMedia ul li a.site-button{background-color: '.$innerpageblogsocialbgColors.';}

.socialMedia ul:hover li.share-button a.site-button,
.socialMedia ul li a.site-button:hover, main#innerpage-box #blog-box .socialMedia ul li a.site-button:hover
{color: '.$innerpageblogsocialhoverColors.';}
.socialMedia ul:hover li.share-button a.site-button, main#innerpage-box #blog-box .socialMedia ul:hover li.share-button a.site-button, main#innerpage-box #blog-box .socialMedia ul li a.site-button:hover
{background-color: '.$innerpageblogsocialbghoverColors.';}

#innerpage-box .inner-blogpost-info .readmore a{color: '.$innerpageblogbtntxtClr.';}
#innerpage-box .inner-blogpost-info .readmore a:hover{color: '.$innerpageblogbtntxthvClr.';}
#innerpage-box .inner-blogpost-info .readmore a{background-color: '.$innerpageblogbtnbgClr.';}
#innerpage-box .inner-blogpost-info .readmore a:hover{background-color: '.$innerpageblogbtnbghvClr.';}

main#innerpage-box .ht-blog-thumbnail .overlay{ background: linear-gradient(to right bottom, '.$innerpageblogimgoverlaycolor1.' 45%, '.$innerpageblogimgoverlaycolor2.' 55%)}


    ';


    $innerpageallothrtheadtextcolcolor = get_theme_mod('luzuk_template_innerpageallothrtheadtextcolcolor_color', '#ffffff');
    $innerpageallothrtheadtextbgsscolcolorcolor = get_theme_mod('luzuk_template_innerpageallothrtheadtextbgsscolcolor_color', '#ffffff');

    $custom_css .= 'div#sitemap-box h3,
#blog-box .blog-read-more a,
    .socialMedia a,
    div#secondary input[type="submit"],
#commentsAdd input[type="submit"],
    .single-productpage #sidebars button,
    .widget_calendar tfoot tr td a, .widget_calendar tfoot tr td a:hover,
    button, input[type="button"], input[type="reset"], input[type="submit"],.woocommerce span.onsale
   {color: '.$innerpageallothrtheadtextcolcolor.';}
    .single-productpage #sidebars button{color: '.$innerpageallothrtheadtextcolcolor.' !important;}
    .woocommerce a.button, .woocommerce-page a.button,
    .woocommerce div.product form.cart .button,
    .woocommerce div.product .woocommerce-tabs ul.tabs li a,
    .woocommerce #review_form #respond .form-submit input,
    .woocommerce button.button,
    .select2-container--default .select2-results__option--highlighted[aria-selected], .select2-container--default .select2-results__option--highlighted[data-selected]{color: '.$innerpageallothrtheadtextcolcolor.' !important;}

    div#secondary select option,
    .select2-container--default .select2-results>.select2-results__options,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
    .woocommerce-page .woocommerce-ordering option,
    .woocommerce-MyAccount-content input[type="text"],
    .woocommerce-MyAccount-content input[type="email"],
    .woocommerce-MyAccount-content input[type="url"], 
    .woocommerce-MyAccount-content input[type="password"],
    .woocommerce form .form-row input.input-text,
    .woocommerce form .form-row textarea,
    .woocommerce-error, 
    .woocommerce-info, 
    .woocommerce-message{background-color: '.$innerpageallothrtheadtextbgsscolcolorcolor.' !important;}

   ';


if(get_theme_mod('luzuk_premium_con_us_section_background','off') == 'on' ){

    $bgimg = get_theme_mod('luzuk_con_us_bg_image');
    $img = !empty($bgimg)?$bgimg:get_template_directory_uri().'/images/default-gray.png';

    $custom_css .= '.ht-contactus-wrap{background-image: url("'.$img.'");background-position: top;background-size: cover;background-attachment: fixed;}';
}else{
    $color = get_theme_mod('luzuk_con_us_bg_color', '#fff');
    if('#fff' != $color){
        $custom_css .= '.ht-contactus-wrap{background-color: '.$color.';}';
    }
}
    // Inner contact us page background color

$contactusmainbx1Clr = get_theme_mod('luzuk_contactus_mainbx1Clr', '#fff');
$contactusmainbx2Clr = get_theme_mod('luzuk_contactus_mainbx2Clr', '#f7c605');
 
$ContactusdetailtitleColor = get_theme_mod('luzuk_contactus_titleColor', '#000');
$contactusrhsbxtleClr = get_theme_mod('luzuk_contactus_rhsbxtleClr', '#fff');
$ContactusdetailiconColor = get_theme_mod('luzuk_contactus_detailiconColor', '#fff');

$ContactusdetailemailColor = get_theme_mod('luzuk_contactus_detailemailColor', '#fff');
$ContactusdetailemailhoverColor = get_theme_mod('luzuk_contactus_detailemailhoverColor', '#f7c605');
$contactusdeSocialicnClr = get_theme_mod('luzuk_contactus_detailSocialicnClr', '#f7c605');
$contactusdeSocialicnhvClr = get_theme_mod('luzuk_contactus_detailSocialicnhvClr', '#fff');
$ContactusboxColor = get_theme_mod('luzuk_contactus_boxColor', '#000');
$Contactusbox1Color = get_theme_mod('luzuk_contactus_box1Color', '#000');

$ContactusformlabelColor = get_theme_mod('luzuk_contactus_formlabelColor', '#000');
$ContactusformtextplaceColor = get_theme_mod('luzuk_contactus_formtextplaceColor', '#000');
//$ContactusformborderbottomColor = get_theme_mod('luzuk_contactus_formborderbottomColor', '#fff');
$ContactusformborderClr = get_theme_mod('luzuk_contactus_formborderClr', '#000');

$ContactusformbtnColor = get_theme_mod('luzuk_contactus_formbtnColor', '#fff');
$ContactusformbtnbgColor = get_theme_mod('luzuk_contactus_formbtnbgColor', '#f7c605');

$ContactusformbtnhoverColor = get_theme_mod('luzuk_contactus_formbtnhoverColor', '#f7c605');
$ContactusformbtnbghoverColor = get_theme_mod('luzuk_contactus_formbtnbghoverColor', '#000');

$ContactussocialtitleColor = get_theme_mod('luzuk_contactus_SocialtitleColor', '#fff');
$ContactussocialtextColor = get_theme_mod('luzuk_contactus_SocialtextColor', '#fff');

    $custom_css .= '#ht-contactus-wrap .contact_l_area, 
#ht-contactus-wrap .contact_l_area small, 
#ht-contactus-wrap h1, #ht-contactus-wrap h1 small,
main#innerpage-box .Address_area h4, 
main#innerpage-box .Address_area h4 small, 
.page-template-contact-template  main#innerpage-box .Address_area h4, 
.page-template-contact-template  main#innerpage-box .Address_area h4 small,
.page-template-contact-template  main#innerpage-box .social_area h4 , 
.page-template-contact-template  main#innerpage-box .social_area h4 small{color: '.$ContactusdetailtitleColor.';}

#innerpage-box .conpage-bx{background: linear-gradient(90deg, '.$contactusmainbx1Clr.' 80%, '.$contactusmainbx2Clr.' 70%);}
#ht-contactus-wrap .address-c-box {background-image: radial-gradient( circle farthest-corner at 10% 20%,'.$Contactusbox1Color.' 0%,'.$ContactusboxColor.' 100.3% );}
#ht-contactus-wrap .social_area a{color: '.$contactusdeSocialicnClr.';}
#ht-contactus-wrap .social_area a:hover span{color: '.$contactusdeSocialicnhvClr.';}
#ht-contactus-wrap .address-c-box .rightbx-tile{color: '.$contactusrhsbxtleClr.';}
#ht-contactus-wrap .contact-info i{color: '.$ContactusdetailiconColor.';}
#ht-contactus-wrap .contact-info a ,
#ht-contactus-wrap .contact-info{color: '.$ContactusdetailemailColor.';}
main#innerpage-box div#ht-contactus-wrap a:hover{color: '.$ContactusdetailemailhoverColor.';}

#ht-contactus-wrap label, div#ht-contactus-wrap div.wpcf7 input[type="file"], div#ht-contactus-wrap div.wpcf7 p {color: '.$ContactusformlabelColor.';}
#ht-contactus-wrap input[type="text"], 
#ht-contactus-wrap input[type="email"], 
#ht-contactus-wrap input[type="url"], 
#ht-contactus-wrap input[type="password"], 
#ht-contactus-wrap input[type="search"], 
#ht-contactus-wrap input[type="number"], 
#ht-contactus-wrap input[type="tel"], 
#ht-contactus-wrap input[type="range"], 
#ht-contactus-wrap input[type="date"], 
#ht-contactus-wrap input[type="month"], 
#ht-contactus-wrap input[type="week"], 
#ht-contactus-wrap input[type="time"], 
#ht-contactus-wrap input[type="datetime"],
#ht-contactus-wrap input[type="datetime-local"], 
#ht-contactus-wrap input[type="color"],
#ht-contactus-wrap select,
#ht-contactus-wrap textarea,
#ht-contactus-wrap input::placeholder,
#ht-contactus-wrap textarea::placeholder,
#ht-contactus-wrap select::placeholder {color: '.$ContactusformtextplaceColor.';}

#ht-contactus-wrap input[type="text"], 
#ht-contactus-wrap input[type="email"], 
#ht-contactus-wrap input[type="url"],
#ht-contactus-wrap input[type="password"], 
#ht-contactus-wrap input[type="search"], 
#ht-contactus-wrap input[type="number"], 
#ht-contactus-wrap input[type="tel"], 
#ht-contactus-wrap input[type="range"], 
#ht-contactus-wrap input[type="date"], 
#ht-contactus-wrap input[type="month"], 
#ht-contactus-wrap input[type="week"], 
#ht-contactus-wrap input[type="time"], 
#ht-contactus-wrap input[type="datetime"], 
#ht-contactus-wrap input[type="datetime-local"], 
#ht-contactus-wrap input[type="color"], 
#ht-contactus-wrap select, 
#ht-contactus-wrap textarea{border-bottom-color: '.$ContactusformborderClr.' !important;}

#ht-contactus-wrap input[type="submit"] {color: '.$ContactusformbtnColor.';}
#ht-contactus-wrap input[type="submit"] {background-color: '.$ContactusformbtnbgColor.';}

#ht-contactus-wrap input[type="submit"]:hover{color: '.$ContactusformbtnhoverColor.';}
#ht-contactus-wrap input[type="submit"]:hover{background-color: '.$ContactusformbtnbghoverColor.';}
main#innerpage-box .social_area h4, main#innerpage-box .social_area h4 small{color: '.$ContactussocialtitleColor.';}
main#innerpage-box .social_area .Contact_area_text{color: '.$ContactussocialtextColor.';}
    
    ';

 $custom = get_post_custom( isset($post->ID) );

    $image_id = get_post_meta( isset($post->ID), '_listing_image_id', true );
    $thumbnail_html = wp_get_attachment_image_src( $image_id, 'larger');

    // echo '<pre />'; print_r($custom);
    if(!empty($custom['useColor']) && $custom['useColor'][0]==1){
        if( isset( $custom['page_bg_color'][0] ) ){
            $custom_css .= '#innerpage-box{background-color:'.$custom['page_bg_color'][0].';}';
        }
    }elseif(!empty($custom['useColor']) && $custom['useColor'][0]==0){
        if( isset( $custom['_listing_image_id'][0]) ){
            $custom_css .= '#innerpage-box{background-image: url(\''.$thumbnail_html[0].'\');background-position: center;background-attachment: fixed;background-origin: content-box;background-size: cover;}';
        }
    }else {
        if( isset( $custom['_listing_image_id'][0]) ){
            $custom_css .= '#innerpage-box{background:none}';
        }
    }

    $custom_css .='.border{border:1px solid #fff;}';

    return punte_css_strip_whitespace($custom_css);
}