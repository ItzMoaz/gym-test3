<?php 
    $wp_customize->add_section(
        'about_area',
        array(
            'title' => __( 'About Us Section', 'luzuk-premium' ),
            'panel' => 'luzuk_premium_home_panel'
        )
    );
    $wp_customize->add_setting(
        'luzuk_about_area_disable',
        array(
            'sanitize_callback' => 'luzuk_sanitize_text',
        )
    );
    $wp_customize->add_control(
        new luzuk_Switch_Control(
            $wp_customize,
            'luzuk_about_area_disable',
            array(
                'settings'      => 'luzuk_about_area_disable',
                'section'       => 'about_area',
                'label'         => __( 'Disable Section', 'luzuk-premium' ),
                'on_off_label'  => array(
                    'on' => __( 'Yes', 'luzuk-premium' ),
                    'off' => __( 'No', 'luzuk-premium' )
                ),
            )
        )
    ); 

backgroundManager($wp_customize, 'about', 'about_area', $color='#f9f9f9', get_template_directory_uri().'/images/default-gray.png', 'img');


lzCustomLable($wp_customize, 'aboutarea_padding', 'about_area', 'Set Section Padding:');

$wp_customize->add_setting(
    'about_areaTpadding',
    array(
        'sanitize_callback' => 'luzuk_sanitize_text',
        'default'           => __( '5em', 'luzuk-premium' )
    )
);
$wp_customize->add_control(
    'about_areaTpadding',
    array(
        'settings'      => 'about_areaTpadding',
        'section'       => 'about_area',
        'type'          => 'text',
        'label'         => __( 'Top Padding', 'luzuk-premium' )
    )
);
$wp_customize->add_setting(
    'about_areaBpadding',
    array(
        'sanitize_callback' => 'luzuk_sanitize_text',
        'default'           => __( '4em', 'luzuk-premium' )
    )
);
$wp_customize->add_control(
    'about_areaBpadding',
    array(
        'settings'      => 'about_areaBpadding',
        'section'       => 'about_area',
        'type'          => 'text',
        'label'         => __( 'Bottom Padding', 'luzuk-premium' )
    )
);


  $wp_customize->add_setting(
        'about_image_heading',
        array(
            'sanitize_callback' => 'luzuk_sanitize_text'
        )
    );
    $wp_customize->add_control(
        new luzuk_Customize_Heading(
            $wp_customize,
            'about_image_heading',
            array(
                'settings'      => 'about_image_heading',
                'section'       => 'about_area',
                'label'         => __( 'Left Box', 'luzuk-premium' ),
            )
        )
    );

 $wp_customize->add_setting(
        'about_title_heading',
        array(
            'sanitize_callback' => 'luzuk_sanitize_text'
        )
    );
    $wp_customize->add_control(
        new luzuk_Customize_Heading(
            $wp_customize,
            'about_title_heading',
            array(
                'settings'      => 'about_title_heading',
                'section'       => 'about_area',
                'label'         => __( 'Section Heading, Sub Heading, Text', 'luzuk-premium' ),
            )
        )
    );    

    $wp_customize->add_setting(
        'about_subtitle',
        array(
            'sanitize_callback' => 'luzuk_sanitize_text',
            'default'           => __( 'About Us', 'luzuk-premium' )
        )
    );
    $wp_customize->add_control(
        'about_subtitle',
        array(
            'settings'      => 'about_subtitle',
            'section'       => 'about_area',
            'type'          => 'text',
            'label'         => __( 'Section Sub Heading', 'luzuk-premium' )
        )
    );

addColorPalatOption($wp_customize, 'about_area_secsubtitle_color', 'about_area', 'Section Sub Heading Color ', '#000');

addColorPalatOption($wp_customize, 'about_area_secsubtitlebrd_clr', 'about_area', 'Section Sub Heading Boreder Color ', '#f7c605');

    $wp_customize->add_setting(
        'about_title',
        array(
            'sanitize_callback' => 'luzuk_sanitize_text',
            'default'           => __( 'THE BEST THING IN TRAINING', 'luzuk-premium' )
        )
    );
    $wp_customize->add_control(
        'about_title',
        array(
            'settings'      => 'about_title',
            'section'       => 'about_area',
            'type'          => 'textarea',
            'label'         => __( 'Section Heading', 'luzuk-premium' )
        )
    );

addColorPalatOption($wp_customize, 'about_area_sectitle_color', 'about_area', 'Heading Color ', '#000');

//addColorPalatOption($wp_customize, 'about_area_sectitlebrd_color', 'about_area', 'Heading Border Color ', '#f63760');

    $wp_customize->add_setting(
        'about_text',
        array(
            'sanitize_callback' => 'luzuk_sanitize_text',
            'default'           => __( 'Porttitor pharetra sollicitudin at tempus phasellus consequat ultrices class sed, quisque non hac diam porta himenaeos fringilla scelerisque, nibh tellus sociosqu molestie conubia sodale.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum.', 'luzuk-premium' )
        )
    );
    $wp_customize->add_control(
        'about_text',
        array(
            'settings'      => 'about_text',
            'section'       => 'about_area',
            'type'          => 'textarea',
            'label'         => __( 'Section Heading Text', 'luzuk-premium' )
        )
    );

addColorPalatOption($wp_customize, 'about_area_text', 'about_area', 'Section Heading Text color', '#7a7878');

    $wp_customize->add_setting(
        'about_textlist',
        array(
            'sanitize_callback' => 'luzuk_sanitize_text',
            'default'           => __( '<li>Lorem ipsum dolor sit amet</li>
        <li>Senectus praesent urna quis</li>
        <li>Pretium class vivamus tellus</li>', 'luzuk-premium' )
        )
    );
    $wp_customize->add_control(
        'about_textlist',
        array(
            'settings'      => 'about_textlist',
            'section'       => 'about_area',
            'type'          => 'textarea',
            'label'         => __( 'Section List Text', 'luzuk-premium' )
        )
    );


//lzCustomLable($wp_customize, 'about_colors', 'about_area', 'Section Color Setting');

addColorPalatOption($wp_customize, 'about_area_pageicon', 'about_area', 'Section List Icon Color', '#f7c605');

addColorPalatOption($wp_customize, 'about_area_pagetitle', 'about_area', 'Section List Icon Title Color', '#7a7878');

addColorPalatOption($wp_customize, 'about_area_pagetext', 'about_area', 'Section Icon Text Color', '#7a7878');

lzCustomLable($wp_customize, 'about_btnclr', 'about_area', 'Section Button Setting');


$wp_customize->add_setting(
    'about_btn_txt',
    array(
        'sanitize_callback' => 'luzuk_sanitize_text',
        'default'           => __( 'Read More' )
    )
);
$wp_customize->add_control(
    'about_btn_txt',
    array(
        'settings'      => 'about_btn_txt',
        'section'       => 'about_area',
        'type'          => 'text',
        'label'         => __( 'Button Text', 'luzuk-premium' )
    )
);
$wp_customize->add_setting('about_btnlink',   array('default'=> 'add link here', 'sanitize_callback' => 'esc_url_raw'));
$wp_customize->add_control('about_btnlink',
    array(
        'settings'      => 'about_btnlink',
        'section'       => 'about_area',
        'type'          => 'url',
        'label'         => __( 'Add Button link here', 'luzuk-premium' )
    )
);

addColorPalatOption($wp_customize, 'about_abtntext', 'about_area', 'Section Button Text Color', '#000');

addColorPalatOption($wp_customize, 'about_abtntexthv', 'about_area', 'Section Button Text Hover Color', '#f7c605');

addColorPalatOption($wp_customize, 'about_abtntextbg', 'about_area', 'Section Button Background Color', '#f7c605');

addColorPalatOption($wp_customize, 'about_abtntextbg', 'about_area', 'Section Button Background Color', '#f7c605');

addColorPalatOption($wp_customize, 'about_abtntextbghv', 'about_area', 'Section Button Background Hover Color', '#000');



lzCustomLable($wp_customize, 'aboutarea_rhssec', 'about_area', 'Right Box ');


lzCustomLable($wp_customize, 'aboutarea_fristimg', 'about_area', 'Section Image');

      $wp_customize->add_setting(
        'about_image',
        array(
            'sanitize_callback' => 'esc_url_raw'
        )
    );
    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize,
            'about_image',
            array(
                'section' => 'about_area',
                'settings' => 'about_image',
                'description' => __('Recommended Image Size: 685X610px', 'luzuk-premium')
            )
        )
    );

addColorPalatOption($wp_customize, 'about_area_simgbrd_color', 'about_area', 'Section Image Border Color ', '#f7c605');
   