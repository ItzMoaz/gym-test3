<?php  
// TESTIMONIALS SECTION START HERE 

$wp_customize->add_section(
    'testimonials_area',
    array(
        'title'         => __( 'Testimonials Section', 'Luzuk Premium' ),
        'panel'   => 'luzuk_premium_home_panel',
    )
); 
    
        $wp_customize->add_setting('luzuk_premium_testimonial_section_lbl', array('sanitize_callback'=>'luzuk_sanitize_text'));
$wp_customize->add_control(
    new luzuk_Info_Text( 
        $wp_customize,
        'luzuk_premium_testimonial_section_lbl',
        array(
            'settings'      => 'luzuk_premium_testimonial_section_lbl',
            'section'       => 'testimonials_area',
            'label'         => __( 'Note:', 'luzuk-premium' ),  
            'description'   => __( '<b>This section available only for PRO version</b><br>If you want this section click on <b>Go Pro</b>', 'luzuk-premium' ),
        )
    )
);