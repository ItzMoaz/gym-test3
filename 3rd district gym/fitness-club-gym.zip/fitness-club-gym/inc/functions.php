<?php
/*services*/
function serviceShortCode($pageId = null, $isCustomizer = false, $i = null) {
    ob_start();

    $args = array('post_type' => 'our-services');
    if (!empty($pageId)) {
        $args['page_id'] = absint($pageId);
    }
    $args['posts_per_page'] = 1;
    $colCls = '';
    // if($isCustomizer == true){
    $cols = get_theme_mod('service_npp_count',5);  
    $services_page_icon1 = get_theme_mod('services_page_icon1'.$i);

    ++$cols;
    switch ($cols) {
       case 1:
                        $colCls = 'col-md-12 col-sm-12 col-xs-12';
                        break;
                        case 2: 
                        $colCls = 'col-md-6 col-sm-6 col-xs-12';
                        break;
                        case 3:
                        case 5:
                        case 6:
                        case 9:
                        case 11:
                        case 13:
                        case 15:
                        $colCls = 'col-md-4 col-sm-6 col-xs-12';
                        break;
                        default: 
                        $colCls = 'col-md-3 col-sm-6 col-xs-12';
                        break;
        }
    // }
        $text = '';
        $query = new WP_Query($args);
        if ($query->have_posts()):
            $postN = 0;

            while ($query->have_posts()) : $query->the_post();
                $luzuk_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'total-service-thumb');
                $post = get_post();

                $servicesNum = get_post_meta($post->ID, 'servicesNum', false);
                $services_Num = !empty($servicesNum[0]) ? $servicesNum[0] : '';
            ?>
        <div class="<?php echo $colCls;?> serbx"> 
        <!-- <div class="item inser"> -->
            <div ser-match-height="groupName" class="single-service-bx">
                <div class="single-service ">
                    <div class="service-icon ">

                       <?php
                        if (has_post_thumbnail()) {
                            $image_url = $luzuk_image[0];
                        } else {
                            $image_url = get_template_directory_uri() . '/images/services.jpg';
                        }
                        ?>
                        <div class="ser-img">
                            <a href="<?php the_permalink(); ?>">
                                <!-- <div class="ser-icn">       
                                    <i class="fa fa-camera-retro"></i>
                                </div> -->
                                <img class="img-responsive" src="<?php echo esc_url($image_url); ?>" alt="<?php the_title(); ?>" />
                                <div class="ser-olay"></div>
                            </a>
                        </div> 
                    </div>
                    <div class="service-title-box">
                        <a href="<?php the_permalink(); ?>"> <h4 class="inner-area-title "><?php the_title(); ?></h4></a>
                        <p class="inner-area-text">
                            <?php
                                if(has_excerpt()){
                                  echo get_the_excerpt();
                                 }else{
                                  echo luzuk_excerpt( get_the_content() , 80 );
                                 } 
                             ?>
                        </p> 
                        <?php
                            $ser_button1 = get_theme_mod('ser_button1', 'READ MORE');
                        ?>
                    
                    <?php if($ser_button1) { ?>
                        <div class="btn5">  
                            <a href="<?php echo esc_url(get_permalink()); ?>">
                                <?php echo $ser_button1 ?> 
                            </a>
                        </div> 
                    <?php }?>
                    </div>
                     
                    <div class="clearfix"></div>
                </div>
                <div class="clearfix"></div> 
            </div>             
        </div>


                <?php
            endwhile;
            $text = ob_get_contents();
            ob_clean();
        endif;
        wp_reset_postdata();
        return $text;
    }


function serviceInnerpageShortCode($pageId = null, $isCustomizer = false, $i = null) {
    ob_start();

    $args = array('post_type' => 'our-services');
    if (!empty($pageId)) {
        $args['page_id'] = absint($pageId);
    }
    $args['posts_per_page'] = -1;
    $colCls = '';
    // if($isCustomizer == true){
    $cols = get_theme_mod('serviceinner_npp_count',2);  
    //$services_page_icon1 = get_theme_mod('services_page_icon1'.$i);

    ++$cols;
    switch ($cols) {
       case 1:
                        $colCls = 'col-md-12 col-sm-12 col-xs-12';
                        break;
                        case 2: 
                        $colCls = 'col-md-6 col-sm-6 col-xs-12';
                        break;
                        case 3:
                        case 5:
                        case 6:
                        case 9:
                        case 11:
                        case 13:
                        case 15:
                        $colCls = 'col-md-4 col-sm-6 col-xs-12';
                        break;
                        default: 
                        $colCls = 'col-md-3 col-sm-6 col-xs-12';
                        break;
        }
    // }
        $text = '';
        $query = new WP_Query($args);
        if ($query->have_posts()):
            $postN = 0;

            while ($query->have_posts()) : $query->the_post();
                $luzuk_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'total-service-thumb');
                $post = get_post();

                 $servicesNum = get_post_meta($post->ID, 'servicesNum', false);
                    $services_Num = !empty($servicesNum[0]) ? $servicesNum[0] : '';
                ?>
        <!-- <div class="<?php echo $colCls;?> single-service-bx"> -->
        <div class="item inser">
<!--inner page  -->
        <div ser-match-height="groupName" class="servicesinn">
            <div class="single-service">
                <div class="service-icon padding0">
                   <?php
                        if (has_post_thumbnail()) {
                            $image_url = $luzuk_image[0];
                        } else {
                            $image_url = get_template_directory_uri() . '/images/services.jpg';
                        }
                    ?>
                    <div class="ser-img">
                        <a href="<?php the_permalink(); ?>">
                            <!-- <div class="ser-icn">       
                                <i class="fa fa-camera-retro"></i>
                            </div> -->
                            <img class="img-responsive" src="<?php echo esc_url($image_url); ?>" alt="<?php the_title(); ?>" />
                            <div class="ovrly"></div>  

                        </a>
                    </div> 
                </div>
                <!-- <a href="<?php the_permalink(); ?>"> -->
                    
                <!-- </a> -->
                <div class="service-title-box">
                    <a href="<?php the_permalink(); ?>"> <h3 class="post-title inner-area-title wow fadeInDown"><?php the_title(); ?></h3></a>
                    <p class="post-text inner-area-text wow fadeInDown"> <?php
                        if(has_excerpt()){
                          echo get_the_excerpt();
                         }else{
                          echo luzuk_excerpt( get_the_content() , 100 );
                         } 
                        ?>
                    </p>       
                </div>
               
            <div class="clearfix"></div>
            </div>  
        </div>
        <!--inner page  -->
    <script type="text/javascript">
            var title = 0;
        jQuery("#innerpage-box .single-service").each(function(){
          if ($(this).height() > title) { title = $(this).height(); }
        });
        jQuery("#innerpage-box .single-service").height(title);


        // on Resize change height

        jQuery(window).resize(function(){
          jQuery("#innerpage-box .single-service").height("");
          var title = 0;
          jQuery("#innerpage-box .single-service").each(function(){
            if ($(this).height() > title) { title = $(this).height(); }
          });
          jQuery("#innerpage-box .single-service").height(title);
        });
    </script> 
     
 </div>

   
                <?php
            endwhile;
            $text = ob_get_contents();
            ob_clean();
        endif;
        wp_reset_postdata();
        return $text;
    }

// theme inner page shortcode 
add_shortcode('SERVICES', 'serviceInnerpageShortCode');