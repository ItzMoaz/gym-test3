// custom-script.js

// Get the copyright section element
const copyrightDiv = document.querySelector('.footer-inn-text1');

// Add event listeners only to the copyright section
if (copyrightDiv) {
    copyrightDiv.addEventListener('keydown', function(event) {
        if (event.keyCode == 123 || (event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.keyCode == 85)) {
            event.preventDefault(); // Prevent default action
        }
    }, false); 
 
    copyrightDiv.addEventListener('contextmenu', function(e) {
        e.preventDefault(); // Prevent right-click context menu
    }, false);
}