<?php
/**
 * Template Name: Contact Page
 *
 * @package Luzuk Premium
 */
get_header(); 
?>
  <?php $image = wp_get_attachment_url( get_post_thumbnail_id($post->ID));?>
<header class="page-main-header"  <?php  if (!empty($image)) : ?>
             style="background: url('<?php echo esc_url($image); ?>'); background-repeat: no-repeat; background-size:100%; "
              <?php endif ?>

                >
	<div class="overlay1"></div>
    <div class="container">
        <?php the_title( '<h1 class="ht-main-title ">', '</h1>' ); ?>
        <div class="clearfix"></div>
    </div>
    <?php if( get_theme_mod('breadcrumb_button_display','show' ) == 'show') :
        ?>
        <div class="breadcrumbbox ">
            <div class="container">
                <div class='button'><?php luzuk_lite_the_breadcrumb(); ?></div>
                <!--  <?php //luzuk_lite_the_breadcrumb(); ?> -->
            </div>
        </div>
    <?php endif ?>    
</header><!-- .entry-header --> 

<main id="innerpage-box">
	<!-- <div class="container"> -->
	<div class="inner_contentbox">
		<div class="ht-contactus-wrap innerpage-whitebox">
	<?php 
		$luzuk_contactus_rhstitle = get_theme_mod('luzuk_contactus_rhstitle', 'info');

		$address = get_theme_mod('luzuk_contactus_address', 'Add Contact Address here..');
		$addressdata1 = get_theme_mod('luzuk_contactus_addressdata1', '');
		$addressdata2 = get_theme_mod('luzuk_contactus_addressdata2', '');

		$email = get_theme_mod('luzuk_contactus_email', 'info@example.com');
		$phone = get_theme_mod('luzuk_contactus_phone', '+123 456 7890');
		$time = get_theme_mod('luzuk_contactus_time', ' 08.00 AM - 06.00 PM');
		$shortcode = get_theme_mod('luzuk_contactus_shortcode', 'Add your shortcode through customizer');
		
		$iframe = get_theme_mod('luzuk_contactus_embade', 'Add your Embed code in customizer');

		$facebook = get_theme_mod('luzuk_contactus_facebook', '//facebook.com/');
		$twitter = get_theme_mod('luzuk_contactus_twitter', '//twitter.com/');
		$instagram = get_theme_mod('luzuk_contactus_instagram', 'https://www.instagram.com/');
		$linkedIn = get_theme_mod('luzuk_contactus_linkedin', '//linkedin.com/');

		$luzuk_contactus_maptitle = get_theme_mod('luzuk_contactus_maptitle', 'LOOKING FOR SUPPORT? WE WILL LOVE TO HELP YOU OUT WITH YOUR QUERIES.');

		$luzuk_contactus_formtitle = get_theme_mod('luzuk_contactus_formtitle', 'Enquiry Now');

	?>
			<div id="ht-contactus-wrap">
				<div class="container">
				<div class="row">
					<div class="contactpage-box col-md-12 col-sm-12 pd-0">
						<div class="conpage-bx"></div>
						<div class="col-md-6 ">
							<?php if($luzuk_contactus_formtitle || $shortcode ){ ?>
								<div class="Address_area ">
									
									<h4><?php if($luzuk_contactus_formtitle){ ?>
										<?php echo ($luzuk_contactus_formtitle);  ?>
									</h4>
									<?php } ?>
									<div class="clearfix"></div>
									<div class="contact-page-form " data-wow-duration="3s">
										<p><?php echo do_shortcode($shortcode);?></p>
										<div class="clearfix"></div>
									</div>
								</div>
							<?php } ?>
						</div>
						<div class="col-md-6  pd-0">
						<?php if($phone || $time || $email || $address || $addressdata1 || $addressdata2 || $facebook || $twitter || $instagram || $linkedIn){ ?>
								<div class="address-c-box ">
									<div class="address-box">
										<div class="rightbx-tile">
										<?php echo ($luzuk_contactus_rhstitle);  ?>
									</div>
										<?php if($email ){ ?>
											<div class="contact_area ">	
												<div class="contact-info" data-wow-duration="1s"> 
													<a href="mailto:<?php echo $email;?>"><i class="fa fa-envelope " aria-hidden="true"></i><?php echo $email;?></a> 
												</div>
												<div class="clearfix"></div>
											</div>
										<?php } ?>
										
										<?php if($phone ){ ?>
											<div class="contact_area ">
												<div class="contact-info " data-wow-duration="2s"> 
													<a href="tel:<?php echo $phone;?>"><i class="fa fa-phone " aria-hidden="true"></i><?php echo $phone;?></a>
												 </div>
												<div class="clearfix"></div>	
											</div>
										<?php } ?>

										<?php if($time ){ ?>
											<div class="contact_area ">
												<div class="contact-info " data-wow-duration="2s"> 
													<i class="fa fa-clock-o " aria-hidden="true"></i><?php echo $time;?>
												 </div>
												<div class="clearfix"></div>	
											</div>
										<?php } ?>

										<?php if( $address || $addressdata1 || $addressdata2){ ?>
										<div class="contact_area ">
											<div class="contact-info " data-wow-duration="3s">
												
												<i class="fa fa-map-marker " aria-hidden="true"></i>
											 	<?php echo nl2br($address); ?><br>
												<?php echo nl2br($addressdata1); ?><br>
												<?php echo nl2br($addressdata2); ?> 
											</div>
												
											<div class="clearfix"></div>	
										</div>
								
										<?php } ?>
										<div class="clearfix"></div>
									</div>
									<?php if( $facebook || $twitter || $instagram || $linkedIn){ ?>
									<div class="social_area ">
										<ul class="contact-sm-links ">
											<?php if(!empty($facebook)){ ?>
												<li ><a href="<?php echo $facebook ?>" title="Facebook" target="_blank"><span class="fa fa-facebook"></span></a></li>
											<?php }?>
											<?php if(!empty($twitter)){ ?>
												<li ><a href="<?php echo $twitter ?>" title="Twitter" target="_blank"><span class="fa-brands fa-x-twitter"></span></a></li>
											<?php }?>
											<?php if(!empty($instagram)){ ?>
												<li ><a href="<?php echo $instagram ?>" title="Instagram"target="_blank"><span class="fa fa-instagram"></span></a></li>
											<?php }?>
											<?php if(!empty($linkedIn)){ ?>
												<li ><a href="<?php echo $linkedIn ?>" title="Linked In" target="_blank"><span class="fa fa-linkedin"></span></a></li>
											<?php }?>
										</ul>
									</div>
									<?php } ?>
									<div class="clearfix"></div>
								</div>
							<?php } ?>
						</div>
					</div>
					<div class="clearfix"></div>
					</div>
				</div>
					<div class="col-md-12 col-sm-12 pd-0">
						<div class="contact-mapbox " data-wow-duration="3s">
							<?php echo $iframe; ?>	
						</div>

					</div>
				</div>
			</div>	
			<div class="clearfix"></div>
	    </div>
	<!-- </div> -->
</main>
<?php get_footer(); ?>