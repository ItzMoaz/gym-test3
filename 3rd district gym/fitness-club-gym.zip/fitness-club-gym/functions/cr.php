<?php
// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly 
}

// Custom copyright function with link to Luzuk
function custom_theme_copyright() {
    $year = date('Y');
    $random_class = 'copyright-' . bin2hex(random_bytes(5));
    $company_name = '<a href="https://luzuk.com/collections/fitness" target="_blank" class="' . esc_attr($random_class) . '">Fitness WordPress Themes</a>';
    return '&copy; ' . $year . ' ' . $company_name . '. All rights reserved.';
}