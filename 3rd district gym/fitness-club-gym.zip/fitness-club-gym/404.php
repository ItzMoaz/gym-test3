<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Luzuk Premium
 */

get_header(); ?>

<main id="innerpage-box">
	<div class="container">
        <div class="inner_contentbox">
			<div class="oops-text"><?php esc_html_e( 'Oops! This Page Could Not Be Found.', 'total' ); ?></div>
			<span class="error-404"><?php esc_html_e( '404', 'total' ); ?></span>
			<div class="oops-text"><?php esc_html_e( 'SORRY BUT THE PAGE YOU ARE LOOKING FOR DOES NOT EXIST, HAVE BEEN REMOVED. NAME CHANGED OR IS TEMPORARILY UNAVAILABLE', 'total' ); ?></div>
        <div class="clearfix"></div>
    </div>
	</div>
</main><!-- #main -->

<?php get_footer(); ?>