<?php
if(get_theme_mod('luzuk_about_area_disable') != 'on' ){
  ?>
  <!-- About Area Start -->
  <?php 
        if( get_theme_mod('about_areaTpadding',true) ) {
          $about_areaTpadding = 'padding-top:'.esc_attr(get_theme_mod('about_areaTpadding')).';';
        }
        if( get_theme_mod('about_areaBpadding',true) ) {
          $about_areaBpadding = 'padding-bottom:'.esc_attr(get_theme_mod('about_areaBpadding')).';';
        }
        if( get_theme_mod('about_areawave',true) ) {
          $about_areawave = 'top:'.esc_attr(get_theme_mod('about_areawave')).';';
        }
        ?>      
  <div class="about-area bg-img-1" id="about">  
      <div class="container">
      <?php
          
          $about_page_id = get_theme_mod('about_page');
          $about_subtitle = get_theme_mod('about_subtitle', 'About Us');
          $abouttitle = get_theme_mod('about_title', 'THE BEST THING IN TRAINING');
          $abouttext = get_theme_mod('about_text', 'Porttitor pharetra sollicitudin at tempus phasellus consequat ultrices class sed, quisque non hac diam porta himenaeos fringilla scelerisque, nibh tellus sociosqu molestie conubia sodale.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum.');

          $abouttextlist = get_theme_mod('about_textlist', '<li>Lorem ipsum dolor sit amet</li>
            <li>Senectus praesent urna quis</li>
            <li>Pretium class vivamus tellus</li>
            ');
      ?>

          <div class="col-md-6 about-rhs" data-wow-duration="1s">
              <div class="row">
                <?php if($about_subtitle ){ ?>
                      <div class="sec-sub-title">
                        <?php echo ($about_subtitle);  ?>
                       
                      </div>
                    <?php }?>
                  <div class="section-title">
                      <h2><?php echo ($abouttitle);  ?></h2> 
                  </div>
                <div class="htext"><?php echo ($abouttext);  ?></div>
              </div>  

              <?php if($abouttextlist){ ?>
              <div class="section-text-list" data-wow-duration="2s">
                  <?php echo ($abouttextlist);  ?>  
              </div>
              <?php
              $aboutbutton = get_theme_mod('about_btn_txt', 'Read More'); 
              $aboutbtnlink = get_theme_mod('about_btnlink', '#');
            ?> 

                <?php if($aboutbutton ){ ?>
                  <div class="about-btn">
                     <a href="<?php echo ($aboutbtnlink);  ?>">     
                        <?php echo ($aboutbutton );  ?>
                      </a>
                  </div>
                <?php }?>
              <?php }?>
              <div class="clearfix"></div>
          </div>
          <div class="col-md-6 abtimg ">
              <!-- <div class="abtimginn pd-0"> -->
                  <div class="abou-img1">
                    <?php 
                        $about_image = get_theme_mod('about_image');
                        if(!empty($about_image)){
                          echo '<img alt="'. esc_html(get_the_title()) .'" src="'.esc_url($about_image).'" class="img-responsive secondry-bg-img" />';
                        }else{
                          echo '<img alt="About us" src="'.get_template_directory_uri().'/images/About1.jpg" class="img-responsive" />';
                        }
                    ?>
                    <div class="abt-imgbrd"></div>
                  </div>
              <!-- </div> -->
          </div>
          <div class="clearfix"></div>
      </div>
      <div class="clearfix"></div> 
  </div>
  <!-- About Area End -->
<?php }  