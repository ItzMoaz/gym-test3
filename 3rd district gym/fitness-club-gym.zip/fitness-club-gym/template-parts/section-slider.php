<?php
/**
 *
 * @package Slider Premium
 */
?>
<?php $showContent = get_theme_mod('slider_section_show_content', 'on'); ?>
<div class="slider_section" id="slider">

	<!-- <div id="ht-bx-slider"> -->
	<div class="owl-slider">
		<div id="carousel" class="owl-carousel">
			<?php
			$args = array( 'post_type' => 'slider', 'orderby'   => 'id', 'order' => 'DESC',);
			if(!empty($pageId)){
				$args['page_id'] = absint($pageId);

			}
			$text = '';
			$query = new WP_Query($args);
			if($query->have_posts()){
				while($query->have_posts()) : $query->the_post(); 
				

				if( get_theme_mod('slider_areaOpacity',true) ) {
					$slider_areaOpacity = 'opacity:'.esc_attr(get_theme_mod('slider_areaOpacity')).';';
				}
				if( get_theme_mod('slider_Tfontsize',true) ) {
					$slider_Tfontsize = 'font-size:'.esc_attr(get_theme_mod('slider_Tfontsize')).';';
				}

				$pageLink = '';
				$slider_btn_link = get_post_meta($post->ID,'slider_btn_link',false);
				$sliderBtnTxt = get_post_meta($post->ID,'sliderBtnTxt',false);
				if(!empty($slider_btn_link) && is_array($slider_btn_link)){
					$pageLink = esc_url(get_permalink($slider_btn_link[0]));
				}
				if(!empty($sliderBtnTxt) && is_array($sliderBtnTxt)){
					$pageLinkTxt = $sliderBtnTxt[0];
				}else{
					$pageLinkTxt = 'Start Free Trial';
				}

				?>
				<div class="item">
					<div class="slider_gradiant"></div> 
					<?php 
						if(has_post_thumbnail()){
							$total_slider_image = wp_get_attachment_image_src(get_post_thumbnail_id(),'full');	
							echo '<img class="slide-mainimg" alt="'. esc_html(get_the_title()) .'" src="'.esc_url($total_slider_image[0]).'">';
					}?>

					<?php
					if($showContent == 'on'){
						?>
						<div class="slider_content " data-wow-duration="1s">
							<div class="title wow bounceInDown">
								<?php echo (get_the_title()); ?>
							</div>
							<div class="sub-title wow bounceInLeft">
								<?php echo (get_the_content()); ?>
							</div>
							<?php 
							if(!empty($pageLink)){ ?>
								<div class="slide-btna">
									<div class="btn5">	
										<a href="<?php echo $pageLink; ?>">
											<?php echo($pageLinkTxt); ?> 
										</a>
									</div>
								</div>
							<?php }?>
						</div>
						<?php }?>

					</div>
					<?php
				endwhile;
			}else{ 
				for($i=0;$i<6;$i++){?>
				<div class="item">
					<div class="slider_gradiant"></div>
						<?php echo '<img class="slide-mainimg" alt="Slider" src="'. esc_html(get_template_directory_uri()) .'/images/slider1.jpg">';?>

					<?php if($showContent == 'on'){?>
				
					<div class="slider_content" data-wow-duration="1s">
						<div class="title wow bounceInDown">Get Fit With Us Lorem Ipsum is simply dummy</div>
						<div class="sub-title wow bounceInLeft">Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has been the industry.</div>
						<div class="slide-btna ">
							<div class="btn5">
								<a href="#">
									<?php _e( 'Get a Free Classes', 'luzuk-premium' ); ?>
								</a>
							</div>
						</div>
					</div>
					<?php }?>
				</div>
				<?php }
			}?>
		</div>
	</div>
	</div>

