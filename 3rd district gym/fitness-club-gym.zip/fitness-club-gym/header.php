<?php    
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Luzuk Premium
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

	<script src="https://use.fontawesome.com/18a9c36ed1.js"></script>
	
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/animate.css" />
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css
" rel="stylesheet">
	
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">

	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">

	<script src="<?php echo get_template_directory_uri(); ?>/js/jquery-3.1.1.slim.min.js" crossorigin="anonymous"></script>
	
	<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js" type="text/javascript"  ></script>

	<script src="<?php echo get_template_directory_uri(); ?>/js/wow.js" ></script>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<div class="main-container">
		<header class="site-header header-transparent header mo-left header-seo">
			<div class="top-bar-head">
				<?php 	
					$header_extphhone = get_theme_mod('header_extphhone', 'Opening Time : ');
					$header_phhone = get_theme_mod('header_phhone', ' 8.00 AM - 12.PM');
					$extheader_call2 = get_theme_mod('extheader_call2', 'Call Us : ');
					$header_call2 = get_theme_mod('header_call2', '502-969-0273');
					
				?>
				
				<!-- <div class="container"> -->
				<div class="row row-eq-height">
					<div class="logo col-md-3 col-sm-3 col-xs-6">
						<div class="inside-full-height">
							<?php 
							
								if( get_theme_mod('pages_logoTopsetmaxwidth',true) ) {
									$pages_logoTopsetmaxwidth = 'max-width:'.esc_attr(get_theme_mod('pages_logoTopsetmaxwidth')).';';
								}
								if( get_theme_mod('pages_logoTpadding',true) ) {
									$pages_logoTpadding = 'padding-top:'.esc_attr(get_theme_mod('pages_logoTpadding')).';';
								}
								if( get_theme_mod('pages_logoBpadding',true) ) {
									$pages_logoBpadding = 'padding-bottom:'.esc_attr(get_theme_mod('pages_logoBpadding')).';';
								}
								if( get_theme_mod('pages_logoLpadding',true) ) {
									$pages_logoLpadding = 'padding-left:'.esc_attr(get_theme_mod('pages_logoLpadding')).';';
								}
								if( get_theme_mod('pages_logoRpadding',true) ) {
									$pages_logoRpadding = 'padding-right:'.esc_attr(get_theme_mod('pages_logoRpadding')).';';
								}

							?>
								<!-- website logo -->
								<div class="logo-header mostion">
									<?php 
									if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) :
										the_custom_logo();
								else : 
									if ( is_front_page() ) : ?>
										<h1 class="ht-site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
										<?php else : ?>
											<p class="ht-site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
										<?php endif; ?>
									<?php endif; ?>
								</div> 
								<p class="ht-site-description"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'description' ); ?></a></p>  
							<!-- nav toggle button -->
							<div class="resp_header_logo">
								<?php 
								if ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) :
									the_custom_logo();
							else : 
								if ( is_front_page() ) : ?>
									<h1 class="ht-site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
									<?php else : ?>
										<p class="ht-site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
									<?php endif; ?>
									<!-- <p class="ht-site-description"><a href="<?php //echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php //bloginfo( 'description' ); ?></a></p> -->
								<?php endif; ?>
							</div>
						</div>
					</div>
				<div class="col-md-8 col-sm-8 col-xs-6 pd-0">	
				<?php if($header_extphhone || $header_phhone || $extheader_call2 || $header_call2 ){ ?>
					<div class="head-inn"> 
						<?php if( $header_extphhone || $header_phhone ){ ?>
						<div class="col-md-7 col-sm-7 col-xs-12 headcontact">
							<div class="Reg">
								<?php if( $header_extphhone || $header_phhone ){ ?>
									<p>
										<i class="fa fa-clock-o"></i> <span> <li><?php echo ($header_extphhone); ?></li> <?php echo ($header_phhone); ?></span>	
									</p>
								<?php } ?>

						 	</div>
						</div>
						<?php } ?>
						<div class="col-md-5 col-sm-5 col-xs-12 headtime">
							<?php if(!empty($extheader_call2 || $header_call2)){ ?>
							<div class="header-call"> 
								<a href="tel:<?php echo $header_call2;?>">
									<i class="fa fa-phone"></i><span class="tooltiptext"><li><?php echo ($extheader_call2); ?></li><?php echo $header_call2;?></span> 
								</a>
							</div>
							<?php }?>
						</div>	
						<div class="clearfix"></div>
					</div>		
				<?php }?>
			
					<div class="col-md-12 col-sm-12 col-xs-12 pd-0 HeaderRbx">
						<div class="header-right">
							<div class="row ">
								<div class="head-menu col-md-12 col-sm-12 pd-0">
									<div class="inside-full-height">
										<div class="site-navigation ">
					                        <div class="nav-menus">                 
												<a href="#" class="js-nav-toggle">
														<span></span>
												</a>
											    <div class="nav-wrapper">
													<nav role="navigation">
														<div class="nav-toggle">
																<span class="nav-back"></span>
																<span class="nav-title">Menu</span>
																<span class="nav-close"></span>
														</div>
														<?php
					                                        if( get_post_meta( get_the_ID(), 'intrinsic_header_page_menu', true) !=='0') {
					                                            wp_nav_menu ( array(
					                                                'menu_class' => 'mainm ht-clearfix',
					                                                'container'=> 'ul',
					                                                'menu' => get_post_meta( get_the_ID(), 'intrinsic_header_page_menu', true),
					                                                'theme_location' => 'primary',  
					                                            )); 
					                                        } else {
					                                            wp_nav_menu ( array(
					                                                'menu_class' => 'mainm ht-clearfix',
					                                                'container'=> 'ul',
					                                                'theme_location' => 'primary',  
					                                            )); 
					                                        }
					                                    ?>
													</nav>
												</div>
											</div>
					                        <nav class="navigation">
			                            		<div class="overlaybg"></div>
					                            <div class="menu-wrapper">
					                                <div class="menu-content">
					                                    <?php
					                                        if( get_post_meta( get_the_ID(), 'intrinsic_header_page_menu', true) !=='0') {
					                                            wp_nav_menu ( array(
					                                                'menu_class' => 'mainmenu ht-clearfix',
					                                                'container'=> 'ul',
					                                                'menu' => get_post_meta( get_the_ID(), 'intrinsic_header_page_menu', true),
					                                                'theme_location' => 'primary',  
					                                            )); 
					                                        } else {
					                                            wp_nav_menu ( array(
					                                                'menu_class' => 'mainmenu ht-clearfix',
					                                                'container'=> 'ul',
					                                                'theme_location' => 'primary',  
					                                            )); 
					                                        }
					                                    ?>
					                                </div> <!-- /.hours-content-->
													<div class="clearfix"></div>
					                            </div><!-- /.menu-wrapper --> 
			                        		</nav>
										 	<div class="clearfix"></div>
										</div><!--  /.site-navigation -->
									</div>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-1 lasthead"></div>
					</div>
				<!-- </div> -->
			</div>
			<div class="clearfix"></div>
		</header>
	</div>
