<?php   
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Luzuk Premium
 */

?>
<?php 
	if( get_theme_mod('sec_footerseTmargin',true) ) {
		$sec_footerseTmargin = 'padding-top:'.esc_attr(get_theme_mod('sec_footerseTmargin')).';';
	}
	if( get_theme_mod('sec_footersebottommargin',true) ) {
		$sec_footersebottommargin = 'padding-bottom:'.esc_attr(get_theme_mod('sec_footersebottommargin')).';';
	}
	if( get_theme_mod('sec_footersecopacity',true) ) {
		$sec_footersecopacity = 'opacity:'.esc_attr(get_theme_mod('sec_footersecopacity')).';';
	}

	$fnewstitle = get_theme_mod('fnewstitle', 'Get More Update Join Our Newsletters');
	$fshortcode = get_theme_mod('luzuk_fshortcode', 'Add your shortcode');
?>		

<footer id="footer" class="footer-area" style="<?php echo esc_attr($sec_footerseTmargin); ?>" "<?php echo esc_attr($sec_footersebottommargin); ?>" "<?php echo esc_attr($sec_footersecopacity); ?>">
	<!-- <div class="fborder"></div> -->
	<?php if(is_active_sidebar('luzuk-footer1') || is_active_sidebar('luzuk-footer2') ){ ?>
		<div class="top-area">
			<div class="container">
				<div class="footer-block">
					<div class="row mr-0">
							<!-- <div class="col-md-5 col-sm-4 pd-0"> -->
								<div class="s-footer single-footer-1">
									<div class="single-footer " data-wow-duration="1s" >
										<?php if(is_active_sidebar('luzuk-footer1')): 
											dynamic_sidebar('luzuk-footer1');
										endif;
										?>	
									</div>
									<div class="clearfix"></div>
								</div>
							<!-- </div> -->

							<!-- <div class="col-md-7 col-sm-8"> -->
								<div class="s-footer col-md-4 col-sm-6 single-footer-2">
									<div class="single-footer " data-wow-duration="1.5s" >
										<?php if(is_active_sidebar('luzuk-footer2')): 
											dynamic_sidebar('luzuk-footer2');
										endif;
										?>	
									</div>
								</div>
								<div class="s-footer col-md-4 col-sm-6 single-footer-3">
									<div class="footer3" >
										<div class="single-footer " data-wow-duration="1.5s" >
											<?php if(is_active_sidebar('luzuk-footer3')): 
												dynamic_sidebar('luzuk-footer3');
											endif;
											?>	
										</div>
									</div>
								</div>
								<div class="s-footer col-md-4 col-sm-6 single-footer-4">
									<div class="single-footer " data-wow-duration="1.5s" >
										<?php if(is_active_sidebar('luzuk-footer4')): 
											dynamic_sidebar('luzuk-footer4');
										endif;
										?>	
									</div>
								</div>
								<div class="clearfix"></div>
								<?php if($fnewstitle || $fshortcode ){ ?>
									<div class="newsletter">
											<div class="row mr-0">
												<div class="col-lg-6 col-md-6 pd-0">
													<h5><?php echo $fnewstitle;?></h5>
												</div>
												<div class="col-lg-6 col-md-6">
													<?php echo do_shortcode($fshortcode);?> 
												</div>
												<div class="clearfix"></div>
											</div>
									</div>
								<?php } ?>
								<div class="clearfix"></div>
							<!-- </div> -->
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="clearfix"></div>
	<?php } ?>

	<?php
		$footerphone = get_theme_mod('footerphone', '+91 800-6539-002');
		$footerphonetext = get_theme_mod('footerphonetext', 'Call - Or - SMS ');
		//$footeremail = get_theme_mod('footeremail', 'info@yourmail.com');

		$footerTermsNdConText = get_theme_mod('footerTermsNdConText', 'Terms & Condition');
		$FooterTermsNdCon = get_theme_mod('footer_termsndondition', '#');
		$FooterPrivacyText = get_theme_mod('footer_privacytext', '#');
		$footerprivtext = get_theme_mod('footerprivtext', 'Privacy Policy');
	?>

	<?php 
		if( get_theme_mod('sec_bottomareaTmargin',true) ) {
			$sec_bottomareaTmargin = 'padding-top:'.esc_attr(get_theme_mod('sec_bottomareaTmargin')).';';
		}
		if( get_theme_mod('sec_bottomareabottommargin',true) ) {
			$sec_bottomareabottommargin = 'padding-bottom:'.esc_attr(get_theme_mod('sec_bottomareabottommargin')).';';
		}
	?>		
		<?php 
		// Prevent direct access
		if ( ! defined( 'ABSPATH' ) ) {
			exit; // Exit if accessed directly
		}

		$footercopyright = '';
		if (function_exists('custom_theme_copyright')) {
			$footercopyright = custom_theme_copyright();
		}
 
	?>

	<!-- <div class="container"> -->
		<div class="col-lg-12 col-md-12 col-sm-12 pd-0">
			<div class="bottom-area " style="<?php echo esc_attr($sec_bottomareaTmargin); ?>" "<?php echo esc_attr($sec_bottomareabottommargin); ?>">
				<div class="container">
					<div class="footer-block">
						<div class="f-contact ">
							<?php if($footerphone || $footerphonetext){ ?>
							<div class="col-md-5 col-sm-4 f-contact-inn fbox1">
								<div class="col-md-2">
									<i class="fa fa-phone"></i>
								</div>
								<div class="col-md-10">
									<?php echo $footerphonetext;?><br>
									<a class="foot-phone" href="tel:<?php echo $footerphone;?>">	
										
										<?php echo $footerphone;?>
									</a>
								</div>
								<div class="clearfix"></div>
							</div>
							<?php } ?>

							<?php if($footercopyright){ ?>
							<div class="col-md-7 col-sm-4 f-contact-inn fbox2">
								<div class="footer-text">
									<?php echo $footercopyright;?>
								</div>
							</div>
							<?php } ?>

							<!-- <?php if($FooterTermsNdCon || $FooterPrivacyText){ ?>
							<div class="col-md-4 col-sm-4 f-contact-inn fbox2">

								<?php if(!empty($FooterTermsNdCon)){ ?>
									<li><a href="<?php echo $FooterTermsNdCon ?>"><?php echo $footerTermsNdConText;?></a></li>
								<?php }?>

								<?php if(!empty($FooterPrivacyText)){ ?>
									<li><a href="<?php echo $FooterPrivacyText ?>"><?php echo $footerprivtext;?></a></li>
								<?php }?>	
								
								<div class="clearfix"></div>
							</div>
							<?php } ?> -->

							
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div>
	<!-- </div> -->
	<div class="clearfix"></div>
</footer><!-- #colophon -->
<script>
        jQuery.noConflict();          
    $(document).ready(function(){
        $("#formButton").click(function(){
            $("#form1").toggle();
        });
    });
</script>

<script type="text/javascript">
	if(jQuery(window).width() >= 1170){
		new WOW().init();
	}
</script>
<script >

$(document).ready(() => {
  
  const back2Top = $('#back2Top')
  const amountScrolled = 300
  
  $(window).scroll(() => {
    $(window).scrollTop() >= amountScrolled 
      ? back2Top.fadeIn('fast') 
      : back2Top.fadeOut('fast')
  })
  
  back2Top.click(() => {
    $('body, html').animate({
      scrollTop: 0
    }, 600)
    return false
  })
})
</script>

<?php wp_footer(); ?>
<a id="back2Top" title="Back to top" href="#"> &#10148; </a>
</body>
</html>
